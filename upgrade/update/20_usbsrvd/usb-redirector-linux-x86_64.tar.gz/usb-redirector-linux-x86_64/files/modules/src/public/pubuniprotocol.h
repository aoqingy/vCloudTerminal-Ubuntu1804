/*
 *
 *  Copyright (C) 2007-2016 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IlllIlIII
#define IlllIlIII
#include "apitypes.h"
#pragma pack(push,1)
enum{lllllIIl=(0x1798+2909-0x22f5),
lIIlllll,
IIllllII,
lIIlIIII,
llIlIIlI,
lllIlIlI,
lIIlIIIl,
lIIlllII,
lllIllll,
llIlIlll,
IIlIIlIll,IIIIllIl,
IllIIIll,
lIIIIlII,
IIlIlIlI,
IIlIIlllI,
lIllllllI,
lIlllllll,};enum{IIllIlIlI=(0x2068+241-0x2159),IIllIIlII,IIlIIIllI,lIIllIIIl,
IIllllIIl,IllIIlIlI,IIlIIllII,llIllIIII,IIIIllIlI,lIllIllll,lllIIlIII,IllllllII,
llIIIlllI,IllIlIlIl,IllIIllII,lIIIIlIII,lllIIIlIl,llIIIlIll};
#define IIIIIl 			(0x93c+6643-0x232e)
#define Illllll 		(0x1f39+1034-0x2341)
#define lIIIIlll          	(0x853+7219-0x2482)
#define llIIIllIl 			(0x1e2f+971-0x21f2)
typedef struct{Illlll lIlIlI:(0xf9d+5387-0x2478);
Illlll lIlIIll:(0x191+7265-0x1de2);lllIl IIIlII;
lllIl IIlIlI;
lllIl Status;lllIl Context;}__attribute__((packed))IllIIlI,*IlIllllIl;
#define IIlIIIlI	(0x339+2732-0xde5)
#define IIIIlllI		(0x1415+3137-0x2055)
#define IllIlIII			(0x56a+5756-0x1be6)
#define IlIIlllI	(0x1fc4+707-0x2286)
#define IIIlIIIl	(0xe6d+2826-0x1975)
#define lIIlIIlIl	(0x13d0+1623-0x1a24)
typedef union{struct{llIIIl IlllIIIl;};struct{llIIIl IIIIIIIl:
(0x639+8272-0x2688);llIIIl IlIIIllll:(0x627+2863-0x1155);llIIIl IIllIlIIl:
(0x1d6f+305-0x1e9f);llIIIl lIIlIllI:(0x23c+8567-0x23b2);llIIIl lIlllIlII:
(0x51c+8080-0x24ab);llIIIl llIIIlll:(0x903+6119-0x20e9);llIIIl lIlIIlIIl:
(0x8b6+7323-0x254f);llIIIl IlIllllI:(0x901+5206-0x1d55);llIIIl IlIlllIlI:
(0x238f+223-0x246c);llIIIl IlIIIllI:(0x1a1d+400-0x1bab);llIIIl lllllllI:
(0xfcd+1758-0x16a9);};}lIlIllllI,*IIlIIIIll;typedef struct{IllIIlI IllIll;IIIII 
IIlllII;
IIIII IIIIIllI;
IIIII IlllIlll;
IIIII IIIIIIlI;llIIIl IllllIll;lllIl IlIll;}__attribute__((packed))IIIlIlllI,*
IIIlllIII;typedef struct{IllIIlI IllIll;IIIII IlIIIIII;IIIII IllllIIl;struct{
IIIII IIllllI;IIIII IlllIII;}__attribute__((packed))lllIlII[(0x1ac4+2625-0x2504)
];}__attribute__((packed))IlllIIIlI,*lIllIlIII;typedef struct{IllIIlI IllIll;
IIIII IIllllI;IIIII IlllIII;}__attribute__((packed))llIlIlllI,*lIIIIllll;
#define IlllllIll			(0x3c0+5275-0x185b)
#define IIllIIllI				(0x3c2+4057-0x139a)
#define IIlllllIl				(0xc3a+2803-0x172b)
#define llIIlIlIl			(0x3e5+8156-0x23be)
#define IllllIIII		(0x6bb+756-0x9af)
#define lIllIllII		(0x5bb+2203-0xe55)
#define lIlIlIIlI		(0x753+2285-0x103e)
#define IlllIIIIl			(0x1090+2724-0x1b31)
#define lIIIIIllI			(0x223+982-0x5f8)
#define llllIlIlI			(0xdd6+2949-0x195b)
typedef struct{IllIIlI IllIll;IIIII Endpoint;IIIII Flags;union{struct{IIIII 
IlIllIlII:(0x440+6234-0x1c95);IIIII lllIIlIll:(0x15e9+3164-0x2243);IIIII 
IllIlIllI:(0x442+4872-0x1749);}__attribute__((packed))llIIIIIIl;IIIII IIlllII;}
__attribute__((packed));IIIII lIlIIIII;llIIIl IlllIIIl;llIIIl IIIIlllll;lllIl 
IlIll;}__attribute__((packed))IlIIlIlll,*llllIlIll;typedef struct{IllIIlI IllIll
;lllIl IlIll;IIIII Endpoint;IIIII Flags;}__attribute__((packed))IlIlllIll,*
lIllIlIIl;typedef struct{IllIIlI IllIll;lllIl IlIll;lllIl Interval;IIIII 
Endpoint;IIIII Flags;}__attribute__((packed))IlIIlIllI,*lllIIIIIl;typedef struct
{IllIIlI IllIll;IIIII Flags;
IIIII Endpoint;}__attribute__((packed))lIllIlIll,*IIllIllll;typedef struct{
IllIIlI IllIll;lllIl lIlllIll;}__attribute__((packed))lIIIlIIIl,*IIlIlIIII;
#define lllIIIlI(IIlIl) (sizeof(llIIIllI) - sizeof(IIIIlII) + \
			sizeof(IIIIlII)*(IIlIl)->llIIl.lIllIlI)
typedef struct{lllIl Offset;lllIl Length;lllIl Status;}__attribute__((packed))
IIIIlII,*lIIllIlIl;typedef struct{IllIIlI IllIll;IIIII Endpoint;IIIII Flags;
lllIl Interval;lllIl lllIIlll;lllIl lIllIlI;lllIl llllIlll;lllIl IlIll;IIIIlII 
IIlIIll[(0xa33+1492-0x1006)];}__attribute__((packed))llIIIllI,*IIllIllII;
#define IIIIIIlll(IIllllIll) (sizeof(lllllIIll)-(0x582+4736-0x1801)+(IIllllIll))
#define IIlIIIlll(IllllIllI) ((IllllIllI)->IIIlI.IIIlII-(sizeof(lllllIIll)-\
(0x6ba+1864-0xe01)))
typedef struct{IllIIlI IllIll;IIIII lIIlIlIII[(0x486+1456-0xa35)];}__attribute__
((packed))lllllIIll,*IllIIIIII;
#define IIIllIlll		(0x157c+1172-0x1a0f)
#define IlIIlIIll		(0x1e5+2725-0xc88)
typedef struct{IllIIlI IllIll;lllIl llllllIl;}__attribute__((packed))IlIllIlll,*
IllIllIII;typedef struct{IllIIlI IllIll;}__attribute__((packed))lIIIIlIlI,*
IIllIIIII;typedef struct{IllIIlI IllIll;}__attribute__((packed))IIIllIlI,*
lIlIlllll;typedef struct{IllIIlI IllIll;IIIII Endpoint;IIIII Flags;}
__attribute__((packed))IIIllIlII,*IIlllllll;
typedef union{IllIIlI IIIlI;IIIlIlllI IllIII;IlllIIIlI IIIIlI;llIlIlllI IlllIIl;
IlIIlIlll IIIllI;IlIlllIll lIllIl;IlIIlIllI IIIIII;lIllIlIll llIlIlI;lIIIlIIIl 
IIlIlIII;llIIIllI llIIl;lllllIIll llllllIII;IlIllIlll IlIllIll;lIIIIlIlI 
IIIlllIlI;IIIllIlI lllIIIIII;IIIllIlII lIIIllll;}__attribute__((packed))
IIllIIIlI,*lIIll;
#pragma pack(pop)
#endif 

