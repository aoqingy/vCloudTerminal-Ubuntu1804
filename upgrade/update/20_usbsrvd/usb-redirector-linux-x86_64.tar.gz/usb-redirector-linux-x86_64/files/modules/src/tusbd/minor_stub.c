/*
 *
 *  Copyright (C) 2007-2016 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifdef _USBD_ENABLE_STUB_
#include "usbd.h"
int IIlIIllll(void*,int);int llIIlIlII(void*,int);void lllllIllI(void*context);
void IIlllIlIl(void*context);unsigned int IIIlIIlll(void*,struct file*,
poll_table*lllIll);long lIlIIllII(void*context,unsigned int llIIII,unsigned long
 llIIlI);
#ifdef CONFIG_COMPAT
long IlllllIII(void*context,unsigned int llIIII,unsigned long llIIlI);
#endif
int lIlIIlIlI(struct IlIII*IIIll);void lIlllIIIl(struct IlIII*IIIll,int status,
gfp_t llllI);void IIIlIIlI(struct IlIII*IIIll,gfp_t llllI);void llIlII(struct 
IlIII*IIIll,int status);void IllllIIlI(struct IlIII*IIIIIlI,gfp_t llllI);void 
lIIIIIlII(struct IlIII*IIIIIlI,gfp_t llllI);void lllllIIII(struct IlIII*IIIIIlI,
gfp_t llllI);void IIIIllIIl(struct IlIII*IIIIIlI,gfp_t llllI);void llIlIIlIl(
struct IlIII*IIIIIlI,gfp_t llllI);void IIIlllIIl(struct IlIII*IIIIIlI,gfp_t 
llllI);void IIlIlllII(struct IlIII*IIIIIlI,gfp_t llllI);
#if KERNEL_GT_EQ((0x204a+357-0x21ad),(0x681+7269-0x22e0),(0x1052+595-0x1286))
void IIIlIIIlI(struct IlIII*IIIIIlI,gfp_t llllI);
#endif
void lllIlIlll(struct IlIII*IIIIIlI,gfp_t llllI);void IllIlllII(struct IlIII*
IIIIIlI,gfp_t llllI);
#if KERNEL_GT_EQ((0xdb2+2904-0x1908),(0xa3d+4136-0x1a5f),(0x2045+306-0x2158))
void llllllIll(struct IlIII*IIIIIlI,gfp_t llllI);
#endif
void IlllIllll(struct IlIII*IIIIIlI,gfp_t llllI);void IIIlIIIll(struct IlIII*
IIIIIlI,gfp_t llllI);void lIIlIIIIl(struct IlIII*IIIIIlI,gfp_t llllI);void 
llIIIIlll(struct IlIII*IIIIIlI,gfp_t llllI);void IlIIllIII(struct IlIII*IIIIIlI,
gfp_t llllI);void llllIlIIl(struct IlIII*IIIIIlI,gfp_t llllI);void IlIlIlIII(
struct IlIII*IIIIIlI,gfp_t llllI);void IIIIIIIII(struct IlIII*IIIIIlI,gfp_t 
llllI);void lIIlIllIl(struct IlIII*IIIIIlI,gfp_t llllI);void lllIlIlIl(struct 
IlIII*IIIll,int status,gfp_t llllI);void lIlIIlll(struct IlIII*IIIll,int status,
gfp_t llllI);void lIlllIIll(struct IlIII*IIIll,int status,gfp_t llllI);void 
IlIIIllII(struct IlIII*IIIll,int status,gfp_t llllI);void IIIIIlIlI(struct IlIII
*IIIll,int status,gfp_t llllI);void lIIlIlIlI(struct IlIII*IIIll,int status,
gfp_t llllI);void IlIIIlIIl(struct IlIII*IIIll,int status,gfp_t llllI);void 
lIIlIIlII(struct IlIII*IIIll,int status,gfp_t llllI);void llllllII(struct IlIII*
IIIll,int status,gfp_t llllI);void IlIlllll(struct IlIII*IIIll,int status,gfp_t 
llllI);void Illlllll(struct IlIII*IIIll,int status,gfp_t llllI);void IIIlIlIl(
struct IlIII*IIIll,int status,gfp_t llllI);
#if KERNEL_LT((0x156+5756-0x17d0),(0xbdd+3841-0x1ad8),(0x52+9896-0x26e7))
void llIIIIII(struct urb*lIlll,struct pt_regs*IIllIII);void IlIlIllI(struct urb*
lIlll,struct pt_regs*IIllIII);void IIIIIlII(struct urb*lIlll,struct pt_regs*
IIllIII);void IIllIllI(struct urb*lIlll,struct pt_regs*IIllIII);void IIIIlIIl(
struct urb*lIlll,struct pt_regs*IIllIII);
#else
void llIIIIII(struct urb*lIlll);void IlIlIllI(struct urb*lIlll);void IIIIIlII(
struct urb*lIlll);void IIllIllI(struct urb*lIlll);void IIIIlIIl(struct urb*lIlll
);
#endif
void IllIllIlI(struct lllIlI*lIIII);void lIIllIllI(struct lllIlI*lIIII);int 
lllIlllI(struct IllIl*lIlII);int IIIlIllll(struct IlIII*IIIll,gfp_t llllI);void 
IllIlIll(struct IllIl*lIlII);void lIIlIlII(struct IllIl*lIlII);void IllIIIIl(
struct IllIl*lIlII,Illlll lIIIl);struct IlIII*IlllIlIl(struct IllIl*lIlII,Illlll
 lIIIl);int llIlIIIll(struct IllIl*lIlII){struct IllllI*lIllI;lIllI=IlIIllI(
sizeof(*lIllI),GFP_KERNEL);if(lIllI){mutex_init(&lIllI->mutex);lIllI->context=
lIlII;lIllI->lIIIll=-(0xb88+3091-0x179a);lIllI->ops.open=IIlIIllll;lIllI->ops.
release=llIIlIlII;lIllI->ops.poll=IIIlIIlll;lIllI->ops.unlocked_ioctl=lIlIIllII;
#ifdef CONFIG_COMPAT
lIllI->ops.compat_ioctl=IlllllIII;
#endif
lIllI->ops.IIlIlIll=lllllIllI;lIllI->ops.IIIIlIll=IIlllIlIl;lIllI->IlllIlI=lIlII
->IlllIlI;lIlII->lIllI=lIllI;return(0x10e8+1843-0x181b);}return-ENOMEM;}void 
IIllllIlI(struct IllIl*lIlII){if(lIlII->lIllI){lIIllllI(lIlII);lllIII(lIlII->
lIllI);lIlII->lIllI=NULL;}}int lIIIlIIll(struct IllIl*lIlII){return lllIIIIl(
lIlII->lIllI,(0x36b+5726-0x19c7),-(0xd1c+2628-0x175f));}void lIIllllI(struct 
IllIl*lIlII){llIlIIIl(lIlII->lIllI);}int IlllIllII(struct IllIl*lIlII,void 
__user*llIlI){ssize_t IlIlI=(0x136+2707-0xbc9);unsigned long flags;struct IlIII*
IIIll;IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2b\x2b" "\n"
);IIIll=NULL;spin_lock_irqsave(&lIlII->lIIllll,flags);if(!list_empty(&lIlII->
IIlIllll)){IIIll=list_entry(lIlII->IIlIllll.next,struct IlIII,IlIlIl);
list_del_init(&IIIll->IlIlIl);}spin_unlock_irqrestore(&lIlII->lIIllll,flags);if(
IIIll){IIlIlllll(IIIll,llIlI,lIIllIIl);lllIllI(IIIll);}else{IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x6e\x6f\x20\x6d\x6f\x72\x65\x20\x64\x61\x74\x61" "\n"
);IlIlI=-ENODATA;}IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x72\x65\x61\x64\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x72\x65\x74\x75\x72\x6e\x69\x6e\x67\x20\x25\x6c\x75" "\n"
,(unsigned long)IlIlI);return IlIlI;}int IllIIIIIl(struct IllIl*lIlII,void 
__user*llIlI){int IlIlI;lIIll IIlIl;struct IlIII*IIIll;IllIIlI IIIlllll;size_t 
IIllIIII;IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x2b\x2b" "\n"
);if(unlikely(IIlllIllI(lIlII))){IIIIll(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x64\x65\x76\x69\x63\x65\x20\x6f\x66\x66\x6c\x69\x6e\x65" "\n"
);return-ENODEV;}if(copy_from_user(&IIIlllll,llIlI,sizeof(IIIlllll))!=
(0x1479+633-0x16f2)){return-EFAULT;}IIllIIII=IIIlllll.IIIlII;if(IIIlllll.IIlIlI
==lIlllllll){IIllIIII-=sizeof(IllIIlI);llIlI+=sizeof(IllIIlI);}while(IIllIIII>
(0x164c+754-0x193e)){IIIll=IlIlIllll(lIlII,llIlI,lIIllIIl);if(!IIIll){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x61\x6c\x6c\x6f\x63\x61\x74\x65\x20\x72\x65\x71\x75\x65\x73\x74" "\n"
);return-ENOMEM;}IIlIl=(lIIll)(IIIll+(0x1bda+2002-0x23ab));IIllIIII-=IIlIl->
IIIlI.IIIlII;llIlI+=IIlIl->IIIlI.IIIlII;IlIIIIl(IIlIl);IlIlI=lIlIIlIlI(IIIll);if
(likely(IlIlI>(0x1e38+1540-0x243c))){
IIIlIIlI(IIIll,GFP_KERNEL);}else if(IlIlI==(0x16d9+2234-0x1f93)){
}else if(IIIll->lIlllIl)
{lllIllI(IIIll);}else{lIlllIIIl(IIIll,IlIlI,GFP_KERNEL);llIlII(IIIll,IlIlI);}}
IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x30" "\n"
);return(0x633+5895-0x1d3a);}int lIllIIlll(struct IllIl*lIlII){unsigned long 
flags;struct list_head llIlIll;IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x64\x72\x61\x69\x6e\x5f\x72\x65\x71\x75\x65\x73\x74\x73\x3a\x20\x2b\x2b" "\n"
);






IlIlIlII(lIlII,NULL,(0x12e7+4696-0x253e),(0x1184+5051-0x253e));

INIT_LIST_HEAD(&llIlIll);spin_lock_irqsave(&lIlII->lIIllll,flags);
list_splice_init(&lIlII->IIlIllll,&llIlIll);spin_unlock_irqrestore(&lIlII->
lIIllll,flags);while(!list_empty(&llIlIll)){struct IlIII*IIlllIIl;IIlllIIl=
list_entry(llIlIll.next,struct IlIII,IlIlIl);list_del(&IIlllIIl->IlIlIl);lllIllI
(IIlllIIl);}IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x64\x72\x61\x69\x6e\x5f\x72\x65\x71\x75\x65\x73\x74\x73\x3a\x20\x2d\x2d" "\n"
);return(0x5bf+7195-0x21da);}int lllIIllll(struct IllIl*lIlII,struct lIlIlIIII 
__user*ioctl){lllIl lllllI;lllIl lIllllI;if(get_user(lllllI,&ioctl->IIIlIl.
lIIIIII)<(0x2052+1496-0x262a))return-EFAULT;if(lllllI!=sizeof(struct lIlIlIIII))
return-EINVAL;if(get_user(lIllllI,&ioctl->lIllllI)<(0x766+1778-0xe58))return-
EFAULT;if(lIllllI>=llIlllIll)return-EINVAL;lIlII->IIIlIIII=lIllllI;return
(0xc3f+1813-0x1354);}int IllIllIIl(struct IllIl*lIlII,struct llIIlIIll __user*
ioctl){lllIl lllllI;lllIl lIIIllII;if(get_user(lllllI,&ioctl->IIIlIl.lIIIIII)<
(0x764+86-0x7ba))return-EFAULT;if(lllllI!=sizeof(struct llIIlIIll))return-EINVAL
;if(get_user(lIIIllII,&ioctl->lIIIllII)<(0xaac+5126-0x1eb2))return-EFAULT;lIlII
->lIIIllII=lIIIllII;return(0x13eb+1013-0x17e0);}
int IIllIlIll(struct IllIl*lIlII,struct IIIIIllII __user*ioctl){lllIl lllllI;if(
get_user(lllllI,&ioctl->IIIlIl.lIIIIII)<(0x195f+280-0x1a77))return-EFAULT;if(
lllllI!=sizeof(struct IIIIIllII))return-EINVAL;lIlIIIlll(lIlII,lIlII->IIIlIIII);
return(0x617+4032-0x15d7);}int llIIIllII(struct IllIl*lIlII,struct lIlIlIIll 
__user*ioctl){lllIl lllllI;lllIl IIllIIll;if(get_user(lllllI,&ioctl->IIIlIl.
lIIIIII)<(0x1963+1100-0x1daf))return-EFAULT;if(lllllI!=sizeof(*ioctl))return-
EINVAL;IIllIIll=lIlII->IIIllIIl;if(put_user(IIllIIll,&ioctl->IIllIIll)<
(0x9dd+5782-0x2073))return-EFAULT;return(0x1b0+1146-0x62a);}long IIIllIllI(void*
context,unsigned int llIIII,void __user*llIIlI){struct IllIl*lIlII=context;
ssize_t IlIlI=(0x121d+4391-0x2344);IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x2b\x2b\x20\x63\x6d\x64\x3d\x25\x64\x20\x61\x72\x67\x3d\x30\x78\x25\x70" "\n"
,llIIII,llIIlI);switch(llIIII){case llIlIIIlI:IlIlI=IlllIllII(lIlII,llIIlI);
break;case IIIIlllII:IlIlI=IllIIIIIl(lIlII,llIIlI);break;case IlllIIlII:IlIlI=
lIllIIlll(lIlII);break;case lIIllllll:IlIlI=lllIIllll(lIlII,llIIlI);break;case 
IIIlIlIlI:IlIlI=IllIllIIl(lIlII,llIIlI);break;case IIIllIIll:IlIlI=IIllIlIll(
lIlII,llIIlI);break;case lIIlllIIl:IlIlI=llIIIllII(lIlII,llIIlI);break;default:
IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x69\x6f\x63\x74\x6c" "\n"
);IlIlI=-EINVAL;break;}IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x69\x6f\x63\x74\x6c\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x6c\x75" "\n"
,(unsigned long)IlIlI);return IlIlI;}long lIlIIllII(void*context,unsigned int 
llIIII,unsigned long llIIlI){return IIIllIllI(context,llIIII,(void __user*)
llIIlI);}
#ifdef CONFIG_COMPAT
long IlllllIII(void*context,unsigned int llIIII,unsigned long llIIlI){return 
IIIllIllI(context,llIIII,compat_ptr(llIIlI));}
#endif


int IIlIIllll(void*context,int IlIllI){int IlIlI=(0x797+4390-0x18bd);
IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6f\x70\x65\x6e\x3a\x20\x2b\x2b\x20\x25\x64" "\n"
,IlIllI);
IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x6f\x70\x65\x6e\x3a\x20\x2d\x2d\x20\x72\x65\x73\x75\x6c\x74\x3d\x25\x64" "\n"
,IlIlI);return IlIlI;}

int llIIlIlII(void*context,int IlIllI){struct IllIl*lIlII=context;IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x72\x65\x6c\x65\x61\x73\x65\x20\x25\x64" "\n"
,IlIllI);if(IlIllI==(0x582+7819-0x240d)){

lIllIIlll(lIlII);if(lIlII->IIIllIIl){lIlIIIlll(lIlII,lIlII->IIIlIIII);}

}return(0xcb3+5353-0x219c);}void lllllIllI(void*context){struct IllIl*lIlII=
context;IlllIIlI(lIlII);}void IIlllIlIl(void*context){struct IllIl*lIlII=context
;lIlIIlIl(lIlII);}unsigned int IIIlIIlll(void*context,struct file*lIIIlI,
poll_table*lllIll){struct IllIl*lIlII=context;int lIIIIllI;unsigned long flags;
poll_wait(lIIIlI,&lIlII->lllIll,lllIll);spin_lock_irqsave(&lIlII->lIIllll,flags)
;lIIIIllI=list_empty(&lIlII->IIlIllll);spin_unlock_irqrestore(&lIlII->lIIllll,
flags);if(!lIIIIllI){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x6d\x69\x6e\x6f\x72\x5f\x70\x6f\x6c\x6c\x3a\x20\x71\x75\x65\x75\x65\x20\x6e\x6f\x74\x20\x65\x6d\x70\x74\x79" "\n"
);return((POLLOUT|POLLWRNORM)|(POLLIN|POLLRDNORM));}return(POLLOUT|POLLWRNORM);}
int lIlIIlIlI(struct IlIII*IIIll){unsigned long flags;struct IllIl*lIlII=IIIll->
lIlII;
if(IIIll->lIlIll.IIIIIIIl==(0xceb+4779-0x1f96)){
spin_lock_irqsave(&lIlII->IlIIIl,flags);list_add_tail(&IIIll->IlIlIl,&lIlII->
lIlIIlI);spin_unlock_irqrestore(&lIlII->IlIIIl,flags);return(0x8dc+852-0xc2f);}
else{
struct lIIIlIlI*IlIIll,*llIIlIIl;struct IlIII*lllIllIl,*llllIIIl;




if(IIIll->lIlIll.IlIIIllll){IlIIll=IlIIllI(sizeof(*IlIIll),GFP_KERNEL);
if(IlIIll==NULL){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x69\x6f\x63\x74\x6c\x5f\x77\x72\x69\x74\x65\x5f\x75\x6e\x72\x62\x3a\x20\x63\x61\x6e\x6e\x6f\x74\x20\x61\x6c\x6c\x6f\x63\x61\x74\x65\x20\x55\x4e\x52\x42" "\n"
);return-ENOMEM;}IlIIll->lIIIl=IIIll->lIIIl;spin_lock_irqsave(&lIlII->IlIIIl,
flags);list_add_tail(&IlIIll->llllII,&lIlII->lIlIIlII);list_add_tail(&IIIll->
IlIlIl,&lIlII->lIlIIlI);spin_unlock_irqrestore(&lIlII->IlIIIl,flags);return
(0x9+2446-0x996);}







spin_lock_irqsave(&lIlII->IlIIIl,flags);

IlIIll=NULL;list_for_each_entry(llIIlIIl,&lIlII->lIlIIlII,llllII){if(llIIlIIl->
lIIIl==IIIll->lIIIl){IlIIll=llIIlIIl;break;}}


if(IlIIll==NULL){spin_unlock_irqrestore(&lIlII->IlIIIl,flags);IIIll->lIlllIl=
(0x19b0+2857-0x24d8);return-ECONNRESET;}


lllIllIl=NULL;list_for_each_entry(llllIIIl,&lIlII->lIlIIlI,IlIlIl){if(llllIIIl->
lIIIl==IIIll->lIIIl&&llllIIIl->lIlIll.IIIIIIIl){lllIllIl=llllIIIl;break;}}


if(lllIllIl==NULL){
if(IlIIll->llIIlIIII){atomic_xchg(&IIIll->state,IIllIIl);IlIIll->llIIlIIII=
(0x161+2465-0xb02);}switch(IlIIll->IlIllIIll){case IllIlIII:
spin_unlock_irqrestore(&lIlII->IlIIIl,flags);IIIll->lIlllIl=(0x1803+878-0x1b70);
return-ECONNRESET;case IlIIlllI:list_add_tail(&IIIll->IlIlIl,&lIlII->lIlIIlI);
spin_unlock_irqrestore(&lIlII->IlIIIl,flags);return(0xfc0+226-0x10a1);case 
IIIlIIIl:atomic_xchg(&IIIll->state,IIllIIl);list_add_tail(&IIIll->IlIlIl,&lIlII
->lIlIIlI);spin_unlock_irqrestore(&lIlII->IlIIIl,flags);return-ECONNRESET;case 
lIIlIIlIl:IlIIll->IlIllIIll=IIIll->lIlIll.IlIIIllI;spin_unlock_irqrestore(&lIlII
->IlIIIl,flags);IIIll->lIlllIl=(0x825+3342-0x1532);return-ECONNRESET;}}





list_add_tail(&IIIll->IlIlIl,&lIlII->lIlIIlI);spin_unlock_irqrestore(&lIlII->
IlIIIl,flags);return(0xf78+5065-0x2341);}}void IIIlIIlI(struct IlIII*IIIll,gfp_t
 llllI){lIIll IIlIl=(lIIll)(IIIll+(0xd2f+3731-0x1bc1));if(unlikely(
atomic_cmpxchg(&IIIll->state,lIlIIIIl,llllIll)!=lIlIIIIl)){lIlllIIIl(IIIll,-
ECONNRESET,llllI);llIlII(IIIll,-ECONNRESET);return;}IIIll->lIlII->IIIllIIl=
(0x29b+3148-0xee6);switch(IIlIl->IIIlI.IIlIlI){case lllllIIl:IllllIIlI(IIIll,
llllI);break;case IIllllII:lIIIIIlII(IIIll,llllI);break;case lIIlIIII:lllllIIII(
IIIll,llllI);break;case llIlIIlI:IIIIllIIl(IIIll,llllI);break;case lllIlIlI:if(
IIIlIllll(IIIll,llllI)>=(0x4d3+1627-0xb2e)){break;}llIlIIlIl(IIIll,llllI);break;
case lIIlllII:lllIlIlll(IIIll,llllI);break;case lIIlIIIl:IlllIllll(IIIll,llllI);
break;case lllIllll:llIIIIlll(IIIll,llllI);break;case llIlIlll:IlIIllIII(IIIll,
llllI);break;case IIIIllIl:llllIlIIl(IIIll,llllI);break;case IllIIIll:IlIlIlIII(
IIIll,llllI);break;case lIIIIlII:IIIIIIIII(IIIll,llllI);break;case IIlIlIlI:
lIIlIllIl(IIIll,llllI);break;}}void lIlllIIIl(struct IlIII*IIIll,int status,
gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+(0x19af+1567-0x1fcd));switch(IIlIl->IIIlI
.IIlIlI){case lllllIIl:lllIlIlIl(IIIll,status,llllI);break;case IIllllII:
lIlIIlll(IIIll,status,llllI);break;case lIIlIIII:IIIIIlIlI(IIIll,status,llllI);
break;case llIlIIlI:llllllII(IIIll,status,llllI);break;case lllIlIlI:IlIlllll(
IIIll,status,llllI);break;case lIIlllII:Illlllll(IIIll,status,llllI);break;case 
lIIlIIIl:IIIlIlIl(IIIll,status,llllI);break;case lllIllll:lIlllIIll(IIIll,status
,llllI);break;case llIlIlll:IlIIIllII(IIIll,status,llllI);break;case IIIIllIl:
lIIlIlIlI(IIIll,status,llllI);break;case IllIIIll:IlIIIlIIl(IIIll,status,llllI);
break;case lIIIIlII:
break;case IIlIlIlI:lIIlIIlII(IIIll,status,llllI);break;}}void IllllIIlI(struct 
IlIII*IIIll,gfp_t llllI){int IlIlI=(0x55c+7430-0x2262);struct usb_ctrlrequest*
IllIIIl;lIIll IIlIl=(lIIll)(IIIll+(0xc15+2318-0x1522));do{struct urb*lIlll;lIlll
=lIIIIlI((0xea1+932-0x1245),llllI);if(unlikely(!lIlll)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x67\x65\x74\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IlIlI=-ENOMEM;break;}IIIll->IlIlII.lIlll=lIlll;IllIIIl=IllllIl(sizeof(*IllIIIl
),llllI);if(unlikely(!IllIIIl)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x67\x65\x74\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IlIlI=-ENOMEM;break;}IllIIIl->bRequest=USB_REQ_GET_DESCRIPTOR;IllIIIl->
bRequestType=USB_DIR_IN+((IIlIl->IllIII.IIlllII&(0xe3a+4148-0x1e6b))<<
(0x1178+3864-0x208b))+(IIlIl->IllIII.IIIIIllI&(0x1aac+1870-0x21db));IllIIIl->
wValue=cpu_to_le16((IIlIl->IllIII.IlllIlll<<(0xe3b+4891-0x214e))+IIlIl->IllIII.
IIIIIIlI);IllIIIl->wIndex=cpu_to_le16(IIlIl->IllIII.IllllIll);IllIIIl->wLength=
cpu_to_le16(IIlIl->IllIII.IlIll);usb_fill_control_urb(lIlll,IIIll->lIlII->llIII,
usb_rcvctrlpipe(IIIll->lIlII->llIII,(0x4f7+5207-0x194e)),(unsigned char*)IllIIIl
,IIIll->IlIlII.IIIIl,IIlIl->IllIII.IlIll,llIIIIII,IIIll);if(atomic_cmpxchg(&
IIIll->state,llllIll,IIIIlIl)!=llllIll){IlIlI=-ECONNRESET;break;}IlIlI=
usb_submit_urb(lIlll,llllI);if(unlikely(IlIlI<(0xab9+5694-0x20f7))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x67\x65\x74\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IlIlI);break;}}while((0x575+4667-0x17b0));if(unlikely(IlIlI<(0x9e3+1190-0xe89))
){lllIlIlIl(IIIll,IlIlI,llllI);llIlII(IIIll,IlIlI);}}void lllIlIlIl(struct IlIII
*IIIll,int status,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+(0xd45+5162-0x216e));
IIlIl->IllIII.IlIll=(0x5af+2290-0xea1);IIlIl->IIIlI.IIIlII=sizeof(IIlIl->IllIII)
+IIlIl->IllIII.IlIll;IIlIl->IIIlI.Status=status;}void lIIIIIlII(struct IlIII*
IIIll,gfp_t llllI){int i;int IlIlI=(0x1de6+1009-0x21d7);lIIll IIlIl=(lIIll)(
IIIll+(0x17ba+2958-0x2347));do
{
IIlIl->IIIlI.Status=(0x1546+460-0x1712);
IlIlIlII(IIIll->lIlII,IIIll,(0x3b+3426-0xd9d),(0xa5f+6188-0x228b));if(IIlIl->
IIIIlI.IlIIIIII==(0x21ed+622-0x245b)){IlIlI=(0xba0+2363-0x14db);break;}
usb_lock_device(IIIll->lIlII->llIII);



if(IIIll->lIlII->llIII->actconfig==NULL||IIIll->lIlII->llIII->actconfig->desc.
bConfigurationValue!=IIlIl->IIIIlI.IlIIIIII){usb_unlock_device(IIIll->lIlII->
llIII);
IlIlI=-EINPROGRESS;break;}IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x6c\x65\x63\x74\x65\x64" "\n"
);
lllIlllI(IIIll->lIlII);for(i=(0xc95+1223-0x115c);i<IIlIl->IIIIlI.IllllIIl;i++){
struct usb_interface*lIllII;struct usb_host_interface*llllllI;lIllII=
usb_ifnum_to_if(IIIll->lIlII->llIII,IIlIl->IIIIlI.lllIlII[i].IIllllI);if(!lIllII
){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,IIlIl->IIIIlI.lllIlII[i].IIllllI);continue;}llllllI=usb_altnum_to_altsetting(
lIllII,IIlIl->IIIIlI.lllIlII[i].IlllIII);if(!llllllI){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67\x20\x25\x64\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,IIlIl->IIIIlI.lllIlII[i].IIllllI,IIlIl->IIIIlI.lllIlII[i].IlllIII);continue;}if
(lIllII->cur_altsetting){if(lIllII->num_altsetting==(0x721+2739-0x11d3)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x68\x61\x73\x20\x6f\x6e\x6c\x79\x20\x6f\x6e\x65\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67" "\n"
,IIlIl->IIIIlI.lllIlII[i].IIllllI);continue;}if(llllllI->desc.bAlternateSetting
==lIllII->cur_altsetting->desc.bAlternateSetting){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x74" "\n"
,IIlIl->IIIIlI.lllIlII[i].IIllllI);continue;}}IlIlI=usb_set_interface(IIIll->
lIlII->llIII,IIlIl->IIIIlI.lllIlII[i].IIllllI,IIlIl->IIIIlI.lllIlII[i].IlllIII);
if(IlIlI!=(0x6b5+925-0xa52)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x75\x73\x62\x5f\x73\x65\x74\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IlIlI);IlIlI=(0xb87+740-0xe6b);
}if(lIllII->cur_altsetting){int llllIl;int pipe;for(llllIl=(0xe5f+1790-0x155d);
llllIl<lIllII->cur_altsetting->desc.bNumEndpoints;llllIl++){if(lIllII->
cur_altsetting->endpoint[llllIl].desc.bEndpointAddress&(0x12ef+3751-0x2116))pipe
=usb_rcvisocpipe(IIIll->lIlII->llIII,lIllII->cur_altsetting->endpoint[llllIl].
desc.bEndpointAddress&(0x661+5650-0x1c64));else pipe=usb_sndisocpipe(IIIll->
lIlII->llIII,lIllII->cur_altsetting->endpoint[llllIl].desc.bEndpointAddress&
(0x697+3477-0x141d));lIlIlIII(IIIll->lIlII,pipe,(0xcc+2415-0xa3b));}}}
usb_unlock_device(IIIll->lIlII->llIII);}while((0x10e3+945-0x1494));if(unlikely(
IlIlI<(0x980+3849-0x1889))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x63\x6f\x6e\x66\x69\x67\x75\x72\x61\x74\x69\x6f\x6e\x3a\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IlIlI);lIlIIlll(IIIll,IlIlI,llllI);}llIlII(IIIll,IlIlI);}void lIlIIlll(struct 
IlIII*IIIll,int status,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+(0x4d+4658-0x127e)
);IIlIl->IIIlI.Status=status;}void llIIIIlll(struct IlIII*IIIll,gfp_t llllI){int
 IlIlI=(0x2250+233-0x2339);lIIll IIlIl=(lIIll)(IIIll+(0x9fd+1729-0x10bd));
IIlIl->IIIlI.Status=(0x76b+4238-0x17f9);do
{
#if KERNEL_GT_EQ((0x2e0+3625-0x1107),(0x1a41+1477-0x2000),(0xb81+675-0xe1a))
int pipe=(0x601+6207-0x1e40),lllIllII;struct usb_host_endpoint*ep;ep=(IIlIl->
llIlIlI.Flags&IIIIIl)?IIIll->lIlII->llIII->ep_in[IIlIl->llIlIlI.Endpoint]:IIIll
->lIlII->llIII->ep_out[IIlIl->llIlIlI.Endpoint];if(ep){switch(ep->desc.
bmAttributes&USB_ENDPOINT_XFERTYPE_MASK){case USB_ENDPOINT_XFER_ISOC:pipe=(IIlIl
->llIlIlI.Flags&IIIIIl)?usb_rcvisocpipe(IIIll->lIlII->llIII,IIlIl->llIlIlI.
Endpoint):usb_sndisocpipe(IIIll->lIlII->llIII,IIlIl->llIlIlI.Endpoint);break;
case USB_ENDPOINT_XFER_BULK:pipe=(IIlIl->llIlIlI.Flags&IIIIIl)?usb_rcvbulkpipe(
IIIll->lIlII->llIII,IIlIl->llIlIlI.Endpoint):usb_sndbulkpipe(IIIll->lIlII->llIII
,IIlIl->llIlIlI.Endpoint);break;case USB_ENDPOINT_XFER_INT:pipe=(IIlIl->llIlIlI.
Flags&IIIIIl)?usb_rcvintpipe(IIIll->lIlII->llIII,IIlIl->llIlIlI.Endpoint):
usb_sndintpipe(IIIll->lIlII->llIII,IIlIl->llIlIlI.Endpoint);break;case 
USB_ENDPOINT_XFER_CONTROL:default:break;}}
#endif
if(ep&&(ep->desc.bmAttributes&USB_ENDPOINT_XFERTYPE_MASK)==
USB_ENDPOINT_XFER_ISOC){lIlIlIII(IIIll->lIlII,pipe,(0x1ca+307-0x2fd));lllIllII=
usb_pipeendpoint(pipe);
#if KERNEL_GT_EQ((0x133c+1746-0x1a0c),(0x1875+2452-0x2203),(0x75f+157-0x7de))
if(usb_pipein(pipe))lllIllII|=USB_DIR_IN;usb_reset_endpoint(IIIll->lIlII->llIII,
lllIllII);
#else
usb_settoggle(IIIll->lIlII->llIII,lllIllII,usb_pipeout(pipe),
(0x19c2+1624-0x201a));
#endif
IlIlI=(0x1a0+7090-0x1d52);}else{IlIlI=usb_clear_halt(IIIll->lIlII->llIII,pipe);}
}while((0x1ee8+544-0x2108));if(unlikely(IlIlI<(0x875+4321-0x1956))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x63\x6c\x65\x61\x72\x73\x74\x61\x6c\x6c\x3a\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IlIlI);lIlllIIll(IIIll,IlIlI,llllI);}llIlII(IIIll,IlIlI);}void lIlllIIll(struct
 IlIII*IIIll,int status,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+(0x825+390-0x9aa)
);IIlIl->IIIlI.Status=status;}void IlIIllIII(struct IlIII*IIIll,gfp_t llllI){
lIIll IIlIl=(lIIll)(IIIll+(0x8cc+2366-0x1209));IIlIl->IIIlI.Status=
(0xd5d+921-0x10f6);IIlIl->IIlIlIII.lIlllIll=usb_get_current_frame_number(IIIll->
lIlII->llIII);llIlII(IIIll,(0xf5+5879-0x17ec));}void IlIIIllII(struct IlIII*
IIIll,int status,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+(0x18d9+2487-0x228f));
IIlIl->IIlIlIII.lIlllIll=(0x5b0+2765-0x107d);IIlIl->IIIlI.Status=status;}void 
lllllIIII(struct IlIII*IIIll,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0xf4a+5528-0x24e1));struct usb_interface*lIllII;struct usb_host_interface*
llllllI;
IIlIl->IIIlI.Status=(0x929+5990-0x208f);usb_lock_device(IIIll->lIlII->llIII);do{
lIllII=usb_ifnum_to_if(IIIll->lIlII->llIII,IIlIl->IlllIIl.IIllllI);if(!lIllII){
IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,IIlIl->IlllIIl.IlllIII);break;}


IIIIIllll(IIIll->lIlII,lIllII,IIIll,(0xe0c+812-0x1138));llllllI=
usb_altnum_to_altsetting(lIllII,IIlIl->IlllIIl.IlllIII);if(!llllllI){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67\x20\x25\x64\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64" "\n"
,IIlIl->IlllIIl.IIllllI,IIlIl->IlllIIl.IlllIII);break;}if(lIllII->cur_altsetting
){if(lIllII->num_altsetting==(0x14f2+2026-0x1cdb)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x68\x61\x73\x20\x6f\x6e\x6c\x79\x20\x6f\x6e\x65\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67" "\n"
,IIlIl->IlllIIl.IIllllI);break;}if(llllllI->desc.bAlternateSetting==lIllII->
cur_altsetting->desc.bAlternateSetting){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x25\x64\x20\x63\x75\x72\x72\x65\x6e\x74\x20\x61\x6c\x74\x73\x65\x74\x74\x69\x6e\x67\x20\x61\x6c\x72\x65\x61\x64\x79\x20\x73\x65\x74" "\n"
,IIlIl->IlllIIl.IIllllI);break;}}IIlIl->IIIlI.Status=usb_set_interface(IIIll->
lIlII->llIII,IIlIl->IlllIIl.IIllllI,IIlIl->IlllIIl.IlllIII);if(IIlIl->IIIlI.
Status!=(0x160+7801-0x1fd9)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x65\x6c\x65\x63\x74\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x3a\x20\x75\x73\x62\x5f\x73\x65\x74\x5f\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IIlIl->IIIlI.Status);}if(lIllII->cur_altsetting){int llllIl;int pipe;for(llllIl
=(0x1134+472-0x130c);llllIl<lIllII->cur_altsetting->desc.bNumEndpoints;llllIl++)
{if(lIllII->cur_altsetting->endpoint[llllIl].desc.bEndpointAddress&
(0x8da+5987-0x1fbd))pipe=usb_rcvisocpipe(IIIll->lIlII->llIII,lIllII->
cur_altsetting->endpoint[llllIl].desc.bEndpointAddress&(0x8bc+959-0xc6c));else 
pipe=usb_sndisocpipe(IIIll->lIlII->llIII,lIllII->cur_altsetting->endpoint[llllIl
].desc.bEndpointAddress&(0xaa8+4997-0x1e1e));lIlIlIII(IIIll->lIlII,pipe,
(0x166+2912-0xcc6));}}}while((0x249+4134-0x126f));if(!IIIll->lIlII->lllIIlI)
{
lllIlllI(IIIll->lIlII);}usb_unlock_device(IIIll->lIlII->llIII);llIlII(IIIll,
(0x18ef+901-0x1c74));}void IIIIIlIlI(struct IlIII*IIIll,int status,gfp_t llllI){
lIIll IIlIl=(lIIll)(IIIll+(0x1f0+7107-0x1db2));IIlIl->IIIlI.Status=status;}void 
llllIlIIl(struct IlIII*IIIll,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0x107+6301-0x19a3));enum usb_device_state state;usb_lock_device(IIIll->lIlII->
llIII);state=IIIll->lIlII->llIII->state;usb_unlock_device(IIIll->lIlII->llIII);
IIlIl->IIIlI.Status=(0xa+3560-0xdf2);IIlIl->IlIllIll.llllllIl=
(0xda5+6361-0x267e);if(state!=USB_STATE_SUSPENDED&&state!=USB_STATE_NOTATTACHED)
{IIlIl->IlIllIll.llllllIl|=IlIIlIIll;if(state==USB_STATE_CONFIGURED)IIlIl->
IlIllIll.llllllIl|=IIIllIlll;}llIlII(IIIll,(0xdda+2094-0x1608));}void lIIlIlIlI(
struct IlIII*IIIll,int status,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0x163+6360-0x1a3a));IIlIl->IlIllIll.llllllIl=(0x295+499-0x488);IIlIl->IIIlI.
Status=status;}void IlIlIlIII(struct IlIII*IIIll,gfp_t llllI){lIIll IIlIl=(lIIll
)(IIIll+(0xd37+4967-0x209d));IIlIl->IIIlI.Status=-(0x1203+564-0x1436);if(IIIll->
lIlII->lllIIlI)
IllIlIll(IIIll->lIlII);if(usb_lock_device_for_reset(IIIll->lIlII->llIII,NULL)>=
(0x189a+782-0x1ba8)){
IIlIl->IIIlI.Status=usb_reset_device(IIIll->lIlII->llIII);usb_unlock_device(
IIIll->lIlII->llIII);}if(IIlIl->IIIlI.Status!=(0x11a5+171-0x1250)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x72\x65\x73\x65\x74\x70\x6f\x72\x74\x3a\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IIlIl->IIIlI.Status);}llIlII(IIIll,IIlIl->IIIlI.Status);}void IlIIIlIIl(struct 
IlIII*IIIll,int status,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0x11b3+4090-0x21ac));IIlIl->IIIlI.Status=status;}void IIIIIIIII(struct IlIII*
IIIll,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+(0x7ef+846-0xb3c));IIlIl->IIIlI.
Status=(0x10d0+2426-0x1a4a);
IIlllIIIl(IIIll->lIlII,IIIll->lIIIl,IIIll);IIIll->lIlllIl=(0xdbf+4982-0x2134);
llIlII(IIIll,(0x35+2911-0xb94));}void lIIlIllIl(struct IlIII*IIIll,gfp_t llllI){
lIIll IIlIl=(lIIll)(IIIll+(0x1ec2+1973-0x2676));int endpoint;endpoint=IIlIl->
lIIIllll.Endpoint;endpoint|=(IIlIl->lIIIllll.Flags&IIIIIl)?(0xef2+2502-0x1838):
(0xe89+5940-0x25bd);IIlIl->IIIlI.Status=(0x1f58+704-0x2218);

lIlIllIlI(IIIll->lIlII,endpoint,IIIll);llIlII(IIIll,(0x11c1+16-0x11d1));}void 
lIIlIIlII(struct IlIII*IIIll,int status,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0x85f+72-0x8a6));IIlIl->IIIlI.Status=status;}void IIIIllIIl(struct IlIII*IIIll,
gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+(0x495+8628-0x2648));int IlIlI=
(0x10b6+990-0x1494);struct usb_ctrlrequest*IllIIIl=NULL;do{struct urb*lIlll;int 
pipe;lIlll=lIIIIlI((0x6e5+5839-0x1db4),llllI);if(unlikely(!lIlll)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IlIlI=-ENOMEM;break;}IIIll->IlIlII.lIlll=lIlll;IllIIIl=IllllIl(sizeof(*IllIIIl
),llllI);if(!IllIIIl){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IlIlI=-ENOMEM;break;}IllIIIl->bRequestType=IIlIl->IIIllI.IIlllII;IllIIIl->
bRequest=IIlIl->IIIllI.lIlIIIII;IllIIIl->wValue=cpu_to_le16(IIlIl->IIIllI.
IlllIIIl);IllIIIl->wIndex=cpu_to_le16(IIlIl->IIIllI.IIIIlllll);IllIIIl->wLength=
cpu_to_le16(IIlIl->IIIllI.IlIll);pipe=(IIlIl->IIIllI.Flags&IIIIIl)?
usb_rcvctrlpipe(IIIll->lIlII->llIII,IIlIl->IIIllI.Endpoint):usb_sndctrlpipe(
IIIll->lIlII->llIII,IIlIl->IIIllI.Endpoint);usb_fill_control_urb(lIlll,IIIll->
lIlII->llIII,pipe,(unsigned char*)IllIIIl,IIIll->IlIlII.IIIIl,IIlIl->IIIllI.
IlIll,IlIlIllI,IIIll);if(atomic_cmpxchg(&IIIll->state,llllIll,IIIIlIl)!=llllIll)
{IlIlI=-ECONNRESET;break;}IlIlI=usb_submit_urb(lIlll,llllI);if(unlikely(IlIlI<
(0x185a+2628-0x229e))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IlIlI);}}while((0x15a2+1660-0x1c1e));if(unlikely(IlIlI<(0x231c+460-0x24e8))){
llllllII(IIIll,IlIlI,llllI);llIlII(IIIll,IlIlI);}}void llllllII(struct IlIII*
IIIll,int status,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+(0xea3+3630-0x1cd0));
IIlIl->IIIllI.IlIll=(0x4e0+6128-0x1cd0);IIlIl->IIIlI.IIIlII=sizeof(IIlIl->IIIllI
);IIlIl->IIIlI.Status=status;}void llIlIIlIl(struct IlIII*IIIll,gfp_t llllI){
switch(IIIll->lIllll){case llIIlIl:IIIlllIIl(IIIll,llllI);return;case lIlllll:
IIlIlllII(IIIll,llllI);return;
#if KERNEL_GT_EQ((0x578+1109-0x9cb),(0x7c4+6965-0x22f3),(0x112+5603-0x16d6))
case lIlIllI:IIIlIIIlI(IIIll,llllI);return;
#endif
default:IlIlllll(IIIll,-EINVAL,llllI);llIlII(IIIll,-EINVAL);return;}}void 
IIIlllIIl(struct IlIII*IIIll,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0x2347+357-0x24ab));int IlIlI=(0x66a+4236-0x16f6);do{struct urb*lIlll;int pipe=
(IIlIl->lIllIl.Flags&IIIIIl)?usb_rcvbulkpipe(IIIll->lIlII->llIII,IIlIl->lIllIl.
Endpoint):usb_sndbulkpipe(IIIll->lIlII->llIII,IIlIl->lIllIl.Endpoint);lIlll=
lIIIIlI((0x752+6151-0x1f59),llllI);if(unlikely(!lIlll)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IlIlI=-ENOMEM;break;}IIIll->IlIlII.lIlll=lIlll;usb_fill_bulk_urb(lIlll,IIIll->
lIlII->llIII,pipe,IIIll->IlIlII.IIIIl,IIlIl->lIllIl.IlIll,IIIIIlII,IIIll);if(
IIlIl->lIllIl.Flags&IIIIIl){if((IIlIl->lIllIl.Flags&Illllll)==
(0x580+6584-0x1f38)){lIlll->transfer_flags|=URB_SHORT_NOT_OK;}}if(unlikely(
atomic_cmpxchg(&IIIll->state,llllIll,IIIIlIl)!=llllIll)){IlIlI=-ECONNRESET;break
;}IlIlI=usb_submit_urb(lIlll,llllI);if(unlikely(IlIlI<(0x18aa+982-0x1c80))){
IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x6f\x6c\x69\x64\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IlIlI);}}while((0x3e3+506-0x5dd));if(unlikely(IlIlI<(0xd52+4566-0x1f28))){
IlIlllll(IIIll,IlIlI,llllI);llIlII(IIIll,IlIlI);}}
#if KERNEL_GT_EQ((0x2e9+3673-0x1140),(0x1082+716-0x1348),(0x676+4469-0x17cc))
void IIIlIIIlI(struct IlIII*IIIll,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0x159+6192-0x1988));int IlIlI=(0x14d+8848-0x23dd);do{struct urb*lIlll;int pipe=
(IIlIl->lIllIl.Flags&IIIIIl)?usb_rcvbulkpipe(IIIll->lIlII->llIII,IIlIl->lIllIl.
Endpoint):usb_sndbulkpipe(IIIll->lIlII->llIII,IIlIl->lIllIl.Endpoint);lIlll=
lIIIIlI((0x12ed+2600-0x1d15),llllI);if(unlikely(!lIlll)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IlIlI=-ENOMEM;break;}IIIll->lIllIll.lIlll=lIlll;usb_fill_bulk_urb(lIlll,IIIll
->lIlII->llIII,pipe,NULL,IIlIl->lIllIl.IlIll,IIIIIlII,IIIll);lIlll->sg=IIIll->
lIllIll.sg.lIIlllI;lIlll->num_sgs=IIIll->lIllIll.sg.num_sgs;if(IIlIl->lIllIl.
Flags&IIIIIl){if((IIlIl->lIllIl.Flags&Illllll)==(0x51f+5886-0x1c1d)){lIlll->
transfer_flags|=URB_SHORT_NOT_OK;}}if(unlikely(atomic_cmpxchg(&IIIll->state,
llllIll,IIIIlIl)!=llllIll)){IlIlI=-ECONNRESET;break;}IlIlI=usb_submit_urb(lIlll,
llllI);if(unlikely(IlIlI<(0x1691+454-0x1857))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x73\x6f\x6c\x69\x64\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64" "\n"
,IlIlI);}}while((0x10d3+1183-0x1572));if(unlikely(IlIlI<(0xf85+3744-0x1e25))){
IlIlllll(IIIll,IlIlI,llllI);llIlII(IIIll,IlIlI);}}
#endif
void IIlIlllII(struct IlIII*IIIll,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0x9e8+6946-0x2509));int IlIlI=(0x752+4744-0x19da);do{int pipe;pipe=(IIlIl->
lIllIl.Flags&IIIIIl)?usb_rcvbulkpipe(IIIll->lIlII->llIII,IIlIl->lIllIl.Endpoint)
:usb_sndbulkpipe(IIIll->lIlII->llIII,IIlIl->lIllIl.Endpoint);IlIlI=lIIIIIlll(&
IIIll->IIllIl.IlIIIII,pipe,(0x1a75+918-0x1e0b),!!(IIlIl->lIllIl.Flags&Illllll),
IIIll->lIlII->lIIIIll,IIIll->lIlII->llIII,&IIIll->IIllIl.lIllIIl,IIIll,IllIllIlI
,llllI);if(unlikely(IlIlI<(0x865+5905-0x1f76))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x73\x62\x64\x5f\x75\x63\x5f\x69\x6e\x69\x74\x20\x66\x61\x69\x6c\x65\x64" "\n"
);break;}if(unlikely(atomic_cmpxchg(&IIIll->state,llllIll,IIIIlIl)!=llllIll)){
IlIlI=-ECONNRESET;break;}IlIlI=lIIllIIII(&IIIll->IIllIl.IlIIIII);if(unlikely(
IlIlI<(0x129a+4816-0x256a))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x73\x62\x64\x5f\x75\x63\x5f\x73\x75\x62\x6d\x69\x74\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64\x20\x66\x6f\x72\x20\x55\x6e\x69\x71\x75\x65\x49\x64\x3d\x30\x78\x25\x2e\x38\x58\x25\x2e\x38\x58" "\n"
,IlIlI,(lllIl)(IIlIl->IIIlI.lIlIlI>>(0x2b4+4123-0x12af)),(lllIl)(IIlIl->IIIlI.
lIlIlI));}}while((0x35+3382-0xd6b));if(unlikely(IlIlI<(0x230+8159-0x220f))){
IlIlllll(IIIll,IlIlI,llllI);llIlII(IIIll,IlIlI);}}void IlIlllll(struct IlIII*
IIIll,int status,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+(0x17b2+1859-0x1ef4));
IIlIl->lIllIl.IlIll=(0x22ef+773-0x25f4);IIlIl->IIIlI.IIIlII=sizeof(IIlIl->lIllIl
)+IIlIl->lIllIl.IlIll;IIlIl->IIIlI.Status=status;}void lllIlIlll(struct IlIII*
IIIll,gfp_t llllI){switch(IIIll->lIllll){case llIIlIl:IllIlllII(IIIll,llllI);
return;
#if KERNEL_GT_EQ((0x10a+1493-0x6dd),(0x10fd+3328-0x1df7),(0x38+9253-0x243e))
case lIlIllI:llllllIll(IIIll,llllI);return;
#endif
default:Illlllll(IIIll,-EINVAL,llllI);llIlII(IIIll,-EINVAL);return;}}void 
IllIlllII(struct IlIII*IIIll,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0x11e3+2413-0x1b4f));int IlIlI=(0x1470+3236-0x2114);do{int pipe;struct urb*
lIlll;struct usb_host_endpoint*ep;lIlll=lIIIIlI((0x60c+280-0x724),llllI);if(
unlikely(!lIlll)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IlIlI=-ENOMEM;break;}IIIll->IlIlII.lIlll=lIlll;pipe=(IIlIl->IIIIII.Flags&
IIIIIl)?usb_rcvintpipe(IIIll->lIlII->llIII,IIlIl->IIIIII.Endpoint):
usb_sndintpipe(IIIll->lIlII->llIII,IIlIl->IIIIII.Endpoint);IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x20\x69\x73\x20\x25\x64" "\n"
,IIlIl->IIIIII.Interval);usb_fill_int_urb(lIlll,IIIll->lIlII->llIII,pipe,IIIll->
IlIlII.IIIIl,IIlIl->IIIIII.IlIll,IIllIllI,IIIll,(0x3ea+6796-0x1e75));if(likely(
IIlIl->IIIIII.Interval)){lIlll->interval=IIlIl->IIIIII.Interval;}else{
#if KERNEL_GT_EQ((0xf7f+740-0x1261),(0xbba+3880-0x1adc),(0xc33+249-0xd22))
ep=(IIlIl->IIIIII.Flags&IIIIIl)?IIIll->lIlII->llIII->ep_in[IIlIl->IIIIII.
Endpoint]:IIIll->lIlII->llIII->ep_out[IIlIl->IIIIII.Endpoint];IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x3d\x25\x73\x20\x65\x70\x3d\x30\x78\x25\x70\x20\x65\x70\x5f\x69\x6e\x5b\x25\x64\x5d\x3d\x30\x78\x25\x70\x20\x65\x70\x5f\x6f\x75\x74\x5b\x25\x64\x5d\x3d\x30\x78\x25\x70" "\n"
,(IIlIl->IIIIII.Flags&IIIIIl)?"\x69\x6e":"\x6f\x75\x74",ep,IIlIl->IIIIII.
Endpoint,IIIll->lIlII->llIII->ep_in[IIlIl->IIIIII.Endpoint],IIlIl->IIIIII.
Endpoint,IIIll->lIlII->llIII->ep_out[IIlIl->IIIIII.Endpoint]);if(ep){if(IIIll->
lIlII->llIII->speed==USB_SPEED_HIGH)lIlll->interval=(0xb92+3501-0x193e)<<(ep->
desc.bInterval-(0xfd9+2944-0x1b58));else lIlll->interval=ep->desc.bInterval;}
else{lIlll->interval=(0x1712+40-0x1739);}
#else
lIlll->interval=(0x1480+4320-0x255f);
#endif
}if(IIlIl->IIIIII.Flags&IIIIIl){if((IIlIl->IIIIII.Flags&Illllll)==
(0x1fc+317-0x339)){lIlll->transfer_flags|=URB_SHORT_NOT_OK;}}if(atomic_cmpxchg(&
IIIll->state,llllIll,IIIIlIl)!=llllIll){IlIlI=-ECONNRESET;break;}while(
(0x7e5+5750-0x1e5a)){IlIlI=usb_submit_urb(lIlll,llllI);if((IlIlI==-ENOMEM)&&(
IIIll->lIlII->llIII->speed==USB_SPEED_HIGH)&&(lIlll->interval<=
(0x54d+1283-0x9d0)))
lIlll->interval<<=(0xa27+964-0xdea);else break;yield();}if(unlikely(IlIlI<
(0xb79+2271-0x1458))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64\x20\x66\x6f\x72\x20\x55\x6e\x69\x71\x75\x65\x49\x64\x3d\x30\x78\x25\x2e\x38\x58\x25\x2e\x38\x58" "\n"
,IlIlI,(lllIl)(IIlIl->IIIlI.lIlIlI>>(0x276+2040-0xa4e)),(lllIl)(IIlIl->IIIlI.
lIlIlI));}}while((0x1a3f+1172-0x1ed3));if(unlikely(IlIlI<(0x1f+4794-0x12d9))){
Illlllll(IIIll,IlIlI,llllI);llIlII(IIIll,IlIlI);}}
#if KERNEL_GT_EQ((0x3c3+7231-0x2000),(0x98c+6414-0x2294),(0x1889+588-0x1ab6))
void llllllIll(struct IlIII*IIIll,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0x83c+1497-0xe14));int IlIlI=(0x7f1+3422-0x154f);do{int pipe;struct urb*lIlll;
struct usb_host_endpoint*ep;lIlll=lIIIIlI((0x811+5101-0x1bfe),llllI);if(unlikely
(!lIlll)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x67\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IlIlI=-ENOMEM;break;}IIIll->lIllIll.lIlll=lIlll;pipe=(IIlIl->IIIIII.Flags&
IIIIIl)?usb_rcvintpipe(IIIll->lIlII->llIII,IIlIl->IIIIII.Endpoint):
usb_sndintpipe(IIIll->lIlII->llIII,IIlIl->IIIIII.Endpoint);IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x20\x69\x73\x20\x25\x64" "\n"
,IIlIl->IIIIII.Interval);usb_fill_int_urb(lIlll,IIIll->lIlII->llIII,pipe,NULL,
IIlIl->IIIIII.IlIll,IIllIllI,IIIll,(0xba+5206-0x150f));lIlll->sg=IIIll->lIllIll.
sg.lIIlllI;lIlll->num_sgs=IIIll->lIllIll.sg.num_sgs;if(likely(IIlIl->IIIIII.
Interval)){lIlll->interval=IIlIl->IIIIII.Interval;}else{
#if KERNEL_GT_EQ((0x8bb+5049-0x1c72),(0x839+11-0x83e),(0x292+7823-0x2117))
ep=(IIlIl->IIIIII.Flags&IIIIIl)?IIIll->lIlII->llIII->ep_in[IIlIl->IIIIII.
Endpoint]:IIIll->lIlII->llIII->ep_out[IIlIl->IIIIII.Endpoint];IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x64\x69\x72\x65\x63\x74\x69\x6f\x6e\x3d\x25\x73\x20\x65\x70\x3d\x30\x78\x25\x70\x20\x65\x70\x5f\x69\x6e\x5b\x25\x64\x5d\x3d\x30\x78\x25\x70\x20\x65\x70\x5f\x6f\x75\x74\x5b\x25\x64\x5d\x3d\x30\x78\x25\x70" "\n"
,(IIlIl->IIIIII.Flags&IIIIIl)?"\x69\x6e":"\x6f\x75\x74",ep,IIlIl->IIIIII.
Endpoint,IIIll->lIlII->llIII->ep_in[IIlIl->IIIIII.Endpoint],IIlIl->IIIIII.
Endpoint,IIIll->lIlII->llIII->ep_out[IIlIl->IIIIII.Endpoint]);if(ep){if(IIIll->
lIlII->llIII->speed==USB_SPEED_HIGH)lIlll->interval=(0x699+538-0x8b2)<<(ep->desc
.bInterval-(0x752+7061-0x22e6));else lIlll->interval=ep->desc.bInterval;}else{
lIlll->interval=(0xa0a+6714-0x2443);}
#else
lIlll->interval=(0x2aa+7902-0x2187);
#endif
}if(IIlIl->IIIIII.Flags&IIIIIl){if((IIlIl->IIIIII.Flags&Illllll)==
(0x1650+671-0x18ef)){lIlll->transfer_flags|=URB_SHORT_NOT_OK;}}if(atomic_cmpxchg
(&IIIll->state,llllIll,IIIIlIl)!=llllIll){IlIlI=-ECONNRESET;break;}while(
(0xb25+2818-0x1626)){IlIlI=usb_submit_urb(lIlll,llllI);if((IlIlI==-ENOMEM)&&(
IIIll->lIlII->llIII->speed==USB_SPEED_HIGH)&&(lIlll->interval<=
(0xa63+2511-0x13b2)))
lIlll->interval<<=(0x17e5+2292-0x20d8);else break;yield();}if(unlikely(IlIlI<
(0x844+3843-0x1747))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64\x20\x66\x6f\x72\x20\x55\x6e\x69\x71\x75\x65\x49\x64\x3d\x30\x78\x25\x2e\x38\x58\x25\x2e\x38\x58" "\n"
,IlIlI,(lllIl)(IIlIl->IIIlI.lIlIlI>>(0x1770+235-0x183b)),(lllIl)(IIlIl->IIIlI.
lIlIlI));}}while((0x2279+1039-0x2688));if(unlikely(IlIlI<(0x1ea9+535-0x20c0))){
Illlllll(IIIll,IlIlI,llllI);llIlII(IIIll,IlIlI);}}
#endif
void Illlllll(struct IlIII*IIIll,int status,gfp_t llllI){lIIll IIlIl=(lIIll)(
IIIll+(0xd93+6098-0x2564));IIlIl->IIIIII.IlIll=(0x4f6+2973-0x1093);IIlIl->IIIlI.
IIIlII=sizeof(IIlIl->IIIIII)+IIlIl->IIIIII.IlIll;IIlIl->IIIlI.Status=status;}
void IlllIllll(struct IlIII*IIIll,gfp_t llllI){switch(IIIll->lIllll){case 
llIIlIl:IIIlIIIll(IIIll,llllI);return;case lIlllll:lIIlIIIIl(IIIll,llllI);return
;default:IIIlIlIl(IIIll,-EINVAL,llllI);llIlII(IIIll,-EINVAL);return;}}void 
lIIlIIIIl(struct IlIII*IIIll,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0x1a11+2386-0x2362));int pipe,IlIlI=(0xb63+3783-0x1a2a);do{int i,llllIl,IIlIII,
IlIIIll,IllIlll,lIIIIIII;int IIIIlIlI;struct urb*lIlll;pipe=(IIlIl->llIIl.Flags&
IIIIIl)?usb_rcvisocpipe(IIIll->lIlII->llIII,IIlIl->llIIl.Endpoint):
usb_sndisocpipe(IIIll->lIlII->llIII,IIlIl->llIIl.Endpoint);lIIIIIII=IIIIIIII(
IIIll->lIlII,pipe);IlIlI=lIIIIIlll(&IIIll->IIllIl.IlIIIII,pipe,IIlIl->llIIl.
Interval,!!(IIlIl->llIIl.Flags&Illllll),IIIll->lIlII->lIIIIll,IIIll->lIlII->
llIII,&IIIll->IIllIl.lIllIIl,IIIll,lIIllIllI,llllI);if(unlikely(IlIlI<
(0x4f0+5731-0x1b53))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x73\x62\x64\x5f\x75\x63\x5f\x69\x6e\x69\x74\x20\x66\x61\x69\x6c\x65\x64" "\n"
);break;}IIIll->IIllIl.IlIIIII.lIlIIl[(0x232+6593-0x1bf3)]->start_frame=IIlIl->
llIIl.lllIIlll;if(!(IIlIl->llIIl.Flags&lIIIIlll))IIIll->IIllIl.IlIIIII.lIlIIl[
(0x16c0+1334-0x1bf6)]->transfer_flags&=~URB_ISO_ASAP;


lIlll=IIIll->IIllIl.IlIIIII.lIlIIl[(0xa39+3473-0x17ca)];IIIIlIlI=
(0xf67+4164-0x1fab);for(i=(0xcb6+25-0xccf),llllIl=(0x2386+603-0x25e1),IIlIII=
(0x1b3+1168-0x643);i<IIlIl->llIIl.lIllIlI;i++,IIlIII++){if(IIlIII>=lIlll->
number_of_packets){if(++llllIl>=IIIll->IIllIl.IlIIIII.IIlII)break;IIIIlIlI=
(0x1155+950-0x150b);lIlll=IIIll->IIllIl.IlIIIII.lIlIIl[llllIl];IIlIII=
(0x202+5281-0x16a3);}lIlll->iso_frame_desc[IIlIII].offset=IIIIlIlI;lIlll->
iso_frame_desc[IIlIII].length=IIlIl->llIIl.IIlIIll[i].Length;IIIIlIlI+=lIlll->
iso_frame_desc[IIlIII].length;
}


IlIIIll=lIIllIII(IIIll->lIlII,pipe);IllIlll=usb_get_current_frame_number(IIIll->
lIlII->llIII);if(!(IIIll->IIllIl.IlIIIII.lIlIIl[(0x804+7103-0x23c3)]->
transfer_flags&URB_ISO_ASAP)&&(IlIIIll==(0x4fb+2586-0xf15))){IlIIIll=(IllIlll+
(0x6c+6063-0x1819))-IIIll->IIllIl.IlIIIII.lIlIIl[(0x4d5+6170-0x1cef)]->
start_frame;lIlIlIII(IIIll->lIlII,pipe,IlIIIll);}if(lIIIIIII==
(0x18bb+1246-0x1d98)){if(IIIll->IIllIl.IlIIIII.lIlIIl[(0xee7+4303-0x1fb6)]->
transfer_flags&URB_ISO_ASAP){IIIll->IIllIl.IlIIIII.lIlIIl[(0x90c+2583-0x1323)]->
transfer_flags&=~URB_ISO_ASAP;IIIll->IIllIl.IlIIIII.lIlIIl[(0x1bd6+1878-0x232c)]
->start_frame=IllIlll+(0x1c2f+263-0x1d35)-IlIIIll;}}if(!(IIIll->IIllIl.IlIIIII.
lIlIIl[(0x1644+2177-0x1ec5)]->transfer_flags&URB_ISO_ASAP)){IIIll->IIllIl.
IlIIIII.lIlIIl[(0x4e2+5426-0x1a14)]->start_frame+=IlIIIll;if(IIIll->IIllIl.
IlIIIII.lIlIIl[(0x1873+1260-0x1d5f)]->start_frame<IllIlll+(0x1c7c+2555-0x2676)){
IIlIl->IIIlI.Status=-EXDEV;IIlIl->IIIlI.IIIlII=lllIIIlI(IIlIl);IIlIl->llIIl.
IlIll=(0x98b+773-0xc90);IIlIl->llIIl.llllIlll=IIlIl->llIIl.lIllIlI;for(i=
(0x480+3608-0x1298);i<IIlIl->llIIl.lIllIlI;i++){IIlIl->llIIl.IIlIIll[i].Status=-
EINVAL;IIlIl->llIIl.IIlIIll[i].Length=(0x86a+6768-0x22da);}IlIlI=
(0x1500+568-0x1738);llIlII(IIIll,-EXDEV);break;}}if(atomic_cmpxchg(&IIIll->state
,llllIll,IIIIlIl)!=llllIll){IlIlI=-ECONNRESET;break;}IlIlI=lIIllIIII(&IIIll->
IIllIl.IlIIIII);if(unlikely(IlIlI<(0xc55+712-0xf1d))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x73\x62\x64\x5f\x75\x63\x5f\x73\x75\x62\x6d\x69\x74\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64\x20\x66\x6f\x72\x20\x55\x6e\x69\x71\x75\x65\x49\x64\x3d\x30\x78\x25\x2e\x38\x58\x25\x2e\x38\x58" "\n"
,IlIlI,(lllIl)(IIlIl->IIIlI.lIlIlI>>(0x1e54+927-0x21d3)),(lllIl)(IIlIl->IIIlI.
lIlIlI));}}while((0x6dd+7771-0x2538));if(unlikely(IlIlI<(0x171b+4058-0x26f5))){
IIlIlIIl(IIIll->lIlII,pipe);IIIlIlIl(IIIll,IlIlI,llllI);llIlII(IIIll,IlIlI);}}
void IIIlIIIll(struct IlIII*IIIll,gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+
(0xcaa+2948-0x182d));int pipe,IlIlI=(0x1b6f+341-0x1cc4);int IIIIlIlI;do{int i,
IlIIIll,IllIlll,lIIIIIII;struct urb*lIlll;struct usb_host_endpoint*ep;pipe=(
IIlIl->llIIl.Flags&IIIIIl)?usb_rcvisocpipe(IIIll->lIlII->llIII,IIlIl->llIIl.
Endpoint):usb_sndisocpipe(IIIll->lIlII->llIII,IIlIl->llIIl.Endpoint);lIIIIIII=
IIIIIIII(IIIll->lIlII,pipe);lIlll=lIIIIlI(IIlIl->llIIl.lIllIlI,llllI);if(
unlikely(!lIlll)){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x6f\x6c\x69\x64\x3a\x20\x75\x73\x62\x5f\x61\x6c\x6c\x6f\x63\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64" "\n"
);IlIlI=-ENOMEM;break;}IIIll->IlIlII.lIlll=lIlll;lIlll->dev=IIIll->lIlII->llIII;
lIlll->pipe=pipe;lIlll->transfer_flags=(IIlIl->llIIl.Flags&lIIIIlll)?
URB_ISO_ASAP:(0xd1f+5856-0x23ff);lIlll->transfer_buffer_length=IIlIl->llIIl.
IlIll;lIlll->start_frame=IIlIl->llIIl.lllIIlll;lIlll->number_of_packets=IIlIl->
llIIl.lIllIlI;lIlll->context=IIIll;lIlll->complete=IIIIlIIl;lIlll->
transfer_buffer=IIIll->IlIlII.IIIIl;if(likely(IIlIl->llIIl.Interval)){lIlll->
interval=IIlIl->llIIl.Interval;}else{
#if KERNEL_GT_EQ((0x566+8292-0x25c8),(0x21c+4176-0x1266),(0x19ba+2286-0x229e))

ep=(IIlIl->llIIl.Flags&IIIIIl)?IIIll->lIlII->llIII->ep_in[IIlIl->llIIl.Endpoint]
:IIIll->lIlII->llIII->ep_out[IIlIl->llIIl.Endpoint];if(ep){if(IIIll->lIlII->
llIII->speed==USB_SPEED_HIGH)lIlll->interval=(0x1548+1848-0x1c7f)<<(ep->desc.
bInterval-(0x248d+36-0x24b0));else lIlll->interval=ep->desc.bInterval;}else{
lIlll->interval=(0x1f68+1291-0x2472);}
#else
lIlll->interval=(0x1601+3625-0x2429);
#endif
}IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x6f\x6c\x69\x64\x3a\x20\x69\x6e\x74\x65\x72\x76\x61\x6c\x20\x69\x73\x20\x25\x64" "\n"
,lIlll->interval);for(IIIIlIlI=(0x178+2149-0x9dd),i=(0x1e14+290-0x1f36);i<IIlIl
->llIIl.lIllIlI;i++){lIlll->iso_frame_desc[i].offset=IIIIlIlI;lIlll->
iso_frame_desc[i].length=IIlIl->llIIl.IIlIIll[i].Length;IIIIlIlI+=lIlll->
iso_frame_desc[i].length;}


IlIIIll=lIIllIII(IIIll->lIlII,pipe);IllIlll=usb_get_current_frame_number(IIIll->
lIlII->llIII);if(!(lIlll->transfer_flags&URB_ISO_ASAP)&&(IlIIIll==
(0x1b35+2736-0x25e5))){IlIIIll=(IllIlll+(0x196+3895-0x10cb))-lIlll->start_frame;
lIlIlIII(IIIll->lIlII,pipe,IlIIIll);}if(lIIIIIII==(0xd14+1946-0x14ad)){if(lIlll
->transfer_flags&URB_ISO_ASAP){lIlll->transfer_flags&=~URB_ISO_ASAP;lIlll->
start_frame=IllIlll+(0x3d+3786-0xf06)-IlIIIll;}}if(!(lIlll->transfer_flags&
URB_ISO_ASAP)){lIlll->start_frame+=IlIIIll;if(lIlll->start_frame<IllIlll+
(0x200a+471-0x21e0)){IIlIl->IIIlI.Status=-EXDEV;IIlIl->IIIlI.IIIlII=lllIIIlI(
IIlIl);IIlIl->llIIl.IlIll=(0x721+4088-0x1719);IIlIl->llIIl.llllIlll=IIlIl->llIIl
.lIllIlI;for(i=(0x96c+3877-0x1891);i<IIlIl->llIIl.lIllIlI;i++){IIlIl->llIIl.
IIlIIll[i].Status=-EINVAL;IIlIl->llIIl.IIlIIll[i].Length=(0x6f3+5232-0x1b63);}
IlIlI=(0x50+990-0x42e);llIlII(IIIll,-EXDEV);break;}}IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x6f\x6c\x69\x64\x3a\x20\x66\x6c\x61\x67\x73\x3d\x25\x64\x20\x73\x74\x61\x72\x74\x66\x72\x61\x6d\x65\x3d\x25\x64\x20\x63\x75\x72\x66\x72\x61\x6d\x65\x3d\x25\x64\x20\x64\x65\x6c\x74\x61\x3d\x25\x64" "\n"
,lIlll->transfer_flags,lIlll->start_frame,usb_get_current_frame_number(IIIll->
lIlII->llIII),lIIllIII(IIIll->lIlII,pipe));if(atomic_cmpxchg(&IIIll->state,
llllIll,IIIIlIl)!=llllIll){IlIlI=-ECONNRESET;break;}IlIlI=usb_submit_urb(lIlll,
llllI);if(unlikely(IlIlI<(0x117+4098-0x1119))){IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x68\x61\x6e\x64\x6c\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x6f\x6c\x69\x64\x3a\x20\x75\x73\x62\x5f\x73\x75\x62\x6d\x69\x74\x5f\x75\x72\x62\x20\x66\x61\x69\x6c\x65\x64\x20\x77\x69\x74\x68\x20\x65\x72\x72\x6f\x72\x20\x25\x64\x20\x66\x6f\x72\x20\x55\x6e\x69\x71\x75\x65\x49\x64\x3d\x30\x78\x25\x6c\x6c\x78" "\n"
,IlIlI,(unsigned long long)IIlIl->IIIlI.lIlIlI);}}while((0xf10+3683-0x1d73));if(
unlikely(IlIlI<(0xb01+2112-0x1341))){IIlIlIIl(IIIll->lIlII,pipe);IIIlIlIl(IIIll,
IlIlI,llllI);llIlII(IIIll,IlIlI);}}void IIIlIlIl(struct IlIII*IIIll,int status,
gfp_t llllI){lIIll IIlIl=(lIIll)(IIIll+(0x1f91+887-0x2307));IIlIl->llIIl.IlIll=
(0xae7+2190-0x1375);IIlIl->IIIlI.IIIlII=lllIIIlI(IIlIl)+IIlIl->llIIl.IlIll;IIlIl
->IIIlI.Status=status;
}void llIIIIII(struct urb*lIlll
#if KERNEL_LT((0x6bb+3432-0x1421),(0xb98+2722-0x1634),(0x1500+911-0x187c))
,struct pt_regs*IIllIII
#endif
){struct IlIII*IIIll=lIlll->context;lIIll IIlIl=(lIIll)(IIIll+
(0x20c7+136-0x214e));IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x67\x65\x74\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72" "\n"
);
IIlIl->IllIII.IlIll=(lIlll->actual_length<(0x196+7127-0x1d6d))?
(0xf92+3748-0x1e36):lIlll->actual_length;IIlIl->IllIII.IllIll.IIIlII=sizeof(
IIlIl->IllIII)+IIlIl->IllIII.IlIll;IIlIl->IllIII.IllIll.Status=lIlll->status;
IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x67\x65\x74\x64\x65\x73\x63\x72\x69\x70\x74\x6f\x72\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,lIlll->status);IlIIIIl(IIlIl);
llIlII(IIIll,lIlll->status);}void IlIlIllI(struct urb*lIlll
#if KERNEL_LT((0x27b+1684-0x90d),(0x15c1+297-0x16e4),(0x5e4+6068-0x1d85))
,struct pt_regs*IIllIII
#endif
){struct IlIII*IIIll=lIlll->context;lIIll IIlIl=(lIIll)(IIIll+
(0x14b3+717-0x177f));IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x74\x72\x61\x6e\x73\x66\x65\x72" "\n"
);
IIlIl->IIIllI.IlIll=(lIlll->actual_length<(0x9fa+2991-0x15a9))?
(0x1e8b+1086-0x22c9):lIlll->actual_length;IIlIl->IIIlI.IIIlII=sizeof(IIlIl->
IIIllI);if(usb_pipein(lIlll->pipe))IIlIl->IIIlI.IIIlII+=IIlIl->IIIllI.IlIll;
IIlIl->IIIllI.IllIll.Status=lIlll->status;IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x63\x6f\x6e\x74\x72\x6f\x6c\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,lIlll->status);IlIIIIl(IIlIl);
llIlII(IIIll,lIlll->status);}void IIIIIlII(struct urb*lIlll
#if KERNEL_LT((0x732+886-0xaa6),(0x92a+1280-0xe24),(0x1d77+1787-0x245f))
,struct pt_regs*IIllIII
#endif
){struct IlIII*IIIll=lIlll->context;lIIll IIlIl=(lIIll)(IIIll+
(0x2036+910-0x23c3));IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72" "\n"
);IIlIl->lIllIl.IlIll=lIlll->actual_length;IIlIl->IIIlI.IIIlII=sizeof(IIlIl->
lIllIl);if(usb_pipein(lIlll->pipe))IIlIl->IIIlI.IIIlII+=IIlIl->lIllIl.IlIll;
IIlIl->lIllIl.IllIll.Status=lIlll->status;IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,lIlll->status);IlIIIIl(IIlIl);
llIlII(IIIll,lIlll->status);}void IIllIllI(struct urb*lIlll
#if KERNEL_LT((0x1959+3221-0x25ec),(0x7cc+1194-0xc70),(0x16e8+1089-0x1b16))
,struct pt_regs*IIllIII
#endif
){struct IlIII*IIIll=lIlll->context;lIIll IIlIl=(lIIll)(IIIll+
(0x208f+1061-0x24b3));IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72" "\n"
);IIlIl->IIIIII.IlIll=lIlll->actual_length;IIlIl->IIIlI.IIIlII=sizeof(IIlIl->
IIIIII);if(usb_pipein(lIlll->pipe))IIlIl->IIIlI.IIIlII+=IIlIl->IIIIII.IlIll;
IIlIl->IIIIII.IllIll.Status=lIlll->status;IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x69\x6e\x74\x65\x72\x72\x75\x70\x74\x74\x72\x61\x6e\x73\x66\x65\x72\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,lIlll->status);IlIIIIl(IIlIl);
llIlII(IIIll,lIlll->status);}void IIIIlIIl(struct urb*lIlll
#if KERNEL_LT((0x5c5+4941-0x1910),(0x574+974-0x93c),(0xaf0+4167-0x1b24))
,struct pt_regs*IIllIII
#endif
){int i;struct IlIII*IIIll=lIlll->context;struct IllIl*lIlII=IIIll->lIlII;lIIll 
IIlIl=(lIIll)(IIIll+(0x968+3466-0x16f1));IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x73\x6f\x6c\x69\x64\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,lIlll->status);IIlIlIIl(lIlII,lIlll->pipe);lIlll->start_frame-=lIIllIII(lIlII,
lIlll->pipe);
#if KERNEL_LT((0xf92+1591-0x15c7),(0x90d+4080-0x18f7),(0x61c+7507-0x2357))


if(lIlll->status!=-ECONNRESET&&lIlll->status!=-ENOENT&&lIlll->status!=-ESHUTDOWN
)lIlll->status=(0x1e6+1914-0x960);
#endif
IIlIl->llIIl.IllIll.Status=lIlll->status;IIlIl->llIIl.llllIlll=lIlll->
error_count;IIlIl->llIIl.lllIIlll=lIlll->start_frame;if(usb_pipein(lIlll->pipe))
{IIlIl->llIIl.IlIll=IIIllIll(lIlll->iso_frame_desc,lIlll->number_of_packets,
lIlll->transfer_buffer,lIlll->transfer_buffer,(0xff+1945-0x897));}else{IIlIl->
llIIl.IlIll=IllIllll(lIlll->iso_frame_desc,lIlll->number_of_packets,
(0x1fb6+59-0x1ff0));}for(i=(0x8c1+5576-0x1e89);i<IIlIl->llIIl.lIllIlI;i++){IIlIl
->llIIl.IIlIIll[i].Length=lIlll->iso_frame_desc[i].actual_length;IIlIl->llIIl.
IIlIIll[i].Status=lIlll->iso_frame_desc[i].status;}IIlIl->IIIlI.IIIlII=lllIIIlI(
IIlIl);if(usb_pipein(lIlll->pipe))IIlIl->IIIlI.IIIlII+=IIlIl->llIIl.IlIll;
IlIIIIl(IIlIl);
#if defined(_USBD_USE_EHCI_FIX_) && KERNEL_GT_EQ((0xc9+2709-0xb5c),\
(0x626+8373-0x26d5),(0x14a3+512-0x168a)) && KERNEL_LT_EQ((0x587+6052-0x1d29),\
(0x160d+1850-0x1d41),(0x6d5+6257-0x1f2a))
if(lIlII->lIIIIll&&(lIlll->status==(0x99f+1431-0xf36))&&(atomic_read(&lIlll->
kref.refcount)>(0xa48+3333-0x174c)))usb_put_urb(lIlll);
#endif

llIlII(IIIll,lIlll->status);}void IllIllIlI(struct lllIlI*lIIII){int i;struct 
IlIII*IIIll=lIIII->context;lIIll IIlIl=(lIIll)(IIIll+(0xc1a+4910-0x1f47));IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64" "\n"
);IIlIl->lIllIl.IlIll=lIIII->lIllllIIl;IIlIl->IIIlI.IIIlII=sizeof(IIlIl->lIllIl)
;if(usb_pipein(lIIII->pipe))IIlIl->lIllIl.IllIll.IIIlII+=IIlIl->lIllIl.IlIll;
IIlIl->lIllIl.IllIll.Status=lIIII->status;for(i=(0x874+4051-0x1847);i<lIIII->
IIlII;i++)IIIll->IIllIl.lIllIIl.actual_length[i]=lIIII->lIlIIl[i]->actual_length
;IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x62\x75\x6c\x6b\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,lIIII->status);IlIIIIl(IIlIl);
llIlII(IIIll,lIIII->status);}void lIIllIllI(struct lllIlI*lIIII){int i,llllIl,
IIlIII;struct IlIII*IIIll=lIIII->context;struct IllIl*lIlII=IIIll->lIlII;lIIll 
IIlIl=(lIIll)(IIIll+(0x1a77+2661-0x24db));IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64" "\n"
);IIlIlIIl(lIlII,lIIII->pipe);lIIII->lIlIIl[(0x4ef+7516-0x224b)]->start_frame-=
lIIllIII(lIlII,lIIII->pipe);IIlIl->llIIl.IllIll.Status=lIIII->status;IIlIl->
llIIl.lllIIlll=lIIII->lIlIIl[(0x65f+490-0x849)]->start_frame;IIlIl->llIIl.
llllIlll=(0x1487+454-0x164d);IIlIl->llIIl.IlIll=(0xee0+424-0x1088);for(i=
(0x9d2+5731-0x2035),IIlIII=(0x13f5+2926-0x1f63);i<lIIII->IIlII;i++){struct urb*
lIlll=lIIII->lIlIIl[i];if(usb_pipein(lIIII->pipe)){IIIll->IIllIl.lIllIIl.
actual_length[i]=IIIllIll(lIlll->iso_frame_desc,lIlll->number_of_packets,lIlll->
transfer_buffer,lIlll->transfer_buffer,(0x1a4d+635-0x1cc7));}else{IIIll->IIllIl.
lIllIIl.actual_length[i]=IllIllll(lIlll->iso_frame_desc,lIlll->number_of_packets
,(0x156d+2399-0x1ecb));}IIlIl->llIIl.IlIll+=IIIll->IIllIl.lIllIIl.actual_length[
i];IIlIl->llIIl.llllIlll+=lIlll->error_count;for(llllIl=(0x858+5643-0x1e63);
llllIl<lIlll->number_of_packets;llllIl++){
IIlIl->llIIl.IIlIIll[IIlIII].Length=lIlll->iso_frame_desc[llllIl].actual_length;
IIlIl->llIIl.IIlIIll[IIlIII].Status=lIlll->iso_frame_desc[llllIl].status;IIlIII
++;}}IIlIl->IIIlI.IIIlII=lllIIIlI(IIlIl);if(usb_pipein(lIIII->pipe))IIlIl->IIIlI
.IIIlII+=IIlIl->llIIl.IlIll;IlllI(
"\x75\x73\x62\x64\x5f\x73\x74\x75\x62\x5f\x75\x72\x62\x5f\x63\x6f\x6d\x70\x6c\x65\x74\x65\x5f\x69\x73\x6f\x63\x68\x74\x72\x61\x6e\x73\x66\x65\x72\x5f\x70\x61\x72\x74\x69\x74\x69\x6f\x6e\x65\x64\x3a\x20\x75\x72\x62\x20\x63\x6f\x6d\x70\x6c\x65\x74\x65\x64\x20\x77\x69\x74\x68\x20\x73\x74\x61\x74\x75\x73\x20\x25\x64" "\n"
,lIIII->status);IlIIIIl(IIlIl);
llIlII(IIIll,lIIII->status);}
void IllIIIIl(struct IllIl*lIlII,Illlll lIIIl){struct lIIIlIlI*IlIIll;

list_for_each_entry(IlIIll,&lIlII->lIlIIlII,llllII){if(IlIIll->lIIIl==lIIIl){
list_del(&IlIIll->llllII);lllIII(IlIIll);return;}}}static inline void IllIIlllI(
struct IllIl*lIlII,Illlll lIIIl,int lIlIIIl){struct lIIIlIlI*IlIIll;
list_for_each_entry(IlIIll,&lIlII->lIlIIlII,llllII){if(IlIIll->lIIIl==lIIIl){
IlIIll->IlIllIIll=lIlIIIl;return;}}}struct IlIII*IlllIlIl(struct IllIl*lIlII,
Illlll lIIIl){struct IlIII*IIIll;list_for_each_entry(IIIll,&lIlII->lIlIIlI,
IlIlIl){if(IIIll->lIIIl==lIIIl){return IIIll;}}return NULL;}struct IlIII*
IllIIllll(struct IlIII*IIIll,int lIlIIIl){struct IlIII*IIIlll;struct list_head*
lIlIlIlI;


if(unlikely(list_empty(&IIIll->IlIlIl)))return NULL;IIIlll=IIIll;
list_for_each_entry_continue(IIIlll,&IIIll->lIlII->lIlIIlI,IlIlIl){if(IIIlll->
lIIIl==IIIll->lIIIl){switch(lIlIIIl){case IllIlIII:lIlIlIlI=IIIlll->IlIlIl.prev;
list_del(&IIIlll->IlIlIl);lllIllI(IIIlll);IIIlll=list_entry(lIlIlIlI,struct 
IlIII,IlIlIl);break;case IlIIlllI:lIlIIIl=lIlIIIl;return IIIlll;case IIIlIIIl:
lIlIIIl=lIlIIIl;atomic_xchg(&IIIlll->state,IIllIIl);return IIIlll;case lIIlIIlIl
:lIlIIIl=IIIlll->lIlIll.IlIIIllI;lIlIlIlI=IIIlll->IlIlIl.prev;list_del(&IIIlll->
IlIlIl);lllIllI(IIIlll);IIIlll=list_entry(lIlIlIlI,struct IlIII,IlIlIl);break;}}
}if(unlikely(lIlIIIl==IllIlIII)){IllIIIIl(IIIll->lIlII,IIIll->lIIIl);}else{
IllIIlllI(IIIll->lIlII,IIIll->lIIIl,lIlIIIl);}
return NULL;}





void llIlII(struct IlIII*IIIll,int status){struct IllIl*lIlII=IlllIIlI(IIIll->
lIlII);struct IlIII*IIlIIIIl=NULL;unsigned long flags;int lllllIlll;int 
IllIlllIl=(0x962+6209-0x21a3);int llIllIIl;int lIlIIIl;spin_lock_irqsave(&lIlII
->IlIIIl,flags);
lllllIlll=atomic_xchg(&IIIll->state,llIlIllII);










if(IIIll->lllIIII&&lllllIlll==IIllIIl&&(status==-ECONNRESET||status==-ENOENT)){
lIIll IIlIl=(lIIll)(IIIll+(0x214+5270-0x16a9));IIlIl->IIIlI.Status=-ESHUTDOWN;
llIll(
"\x72\x65\x71\x75\x65\x73\x74\x20\x63\x61\x6e\x63\x65\x6c\x6c\x65\x64\x20\x64\x75\x65\x20\x74\x6f\x20\x64\x65\x74\x61\x63\x68\x20\x6f\x66\x20\x64\x65\x76\x69\x63\x65" "\n"
);}
if(IIIll->lIlIll.IIIIIIIl){

if(unlikely(lllllIlll==IIllIIl)){




llIllIIl=IIIll->lIlIll.llIIIlll;lIlIIIl=IIIll->lIlIll.lllllllI;
}else if(likely(status==(0x795+1953-0xf36))){llIllIIl=IIIll->lIlIll.IIllIlIIl;
lIlIIIl=IIIll->lIlIll.lIlIIlIIl;
}else if(status==-EREMOTEIO){llIllIIl=IIIll->lIlIll.lIlllIlII;lIlIIIl=IIIll->
lIlIll.IlIlllIlI;
}else{llIllIIl=IIIll->lIlIll.lIIlIllI;lIlIIIl=IIIll->lIlIll.IlIllllI;
}if(unlikely(llIllIIl==IIIIlllI)){IIIll->lIlllIl=(0xe7f+3307-0x1b69);}IIlIIIIl=
IllIIllll(IIIll,lIlIIIl);
}
list_del(&IIIll->IlIlIl);
if(unlikely(IIIll->lIlllIl)){spin_unlock_irqrestore(&lIlII->IlIIIl,flags);
lllIllI(IIIll);}else{spin_lock(&lIlII->lIIllll);list_add_tail(&IIIll->IlIlIl,&
lIlII->IIlIllll);spin_unlock(&lIlII->lIIllll);spin_unlock_irqrestore(&lIlII->
IlIIIl,flags);IllIlllIl=(0xcfb+3898-0x1c34);}
if(IIlIIIIl){





IIIlIIlI(IIlIIIIl,GFP_ATOMIC);}
if(likely(IllIlllIl))wake_up(&lIlII->lllIll);








lIlIIlIl(lIlII);}
int lllIlllI(struct IllIl*lIlII){int i;int llIIIIIl,lIlIIllI;struct usb_device*
IlIIl=lIlII->llIII;llIIIIIl=lIlIIllI=-(0x1617+2972-0x21b2);
for(i=(0x1c77+2166-0x24ed);i<IlIIl->actconfig->desc.bNumInterfaces;i++){struct 
usb_interface*interface=IlIIl->actconfig->interface[i];if(interface==NULL)
continue;if(interface->cur_altsetting==NULL)continue;IlllI(
"\x44\x65\x74\x65\x63\x74\x65\x64\x20\x69\x6e\x74\x65\x72\x66\x61\x63\x65\x20\x63\x6c\x61\x73\x73\x3d\x30\x78\x25\x30\x32\x78\x20\x73\x75\x62\x63\x6c\x61\x73\x73\x3d\x30\x78\x25\x30\x32\x78\x20\x70\x72\x6f\x74\x6f\x63\x6f\x6c\x3d\x30\x78\x25\x30\x32\x78" "\n"
,interface->cur_altsetting->desc.bInterfaceClass,interface->cur_altsetting->desc
.bInterfaceSubClass,interface->cur_altsetting->desc.bInterfaceProtocol);if(
interface->cur_altsetting->desc.bInterfaceClass==(0x3b6+8501-0x24e3)&&interface
->cur_altsetting->desc.bInterfaceProtocol==(0xafc+201-0xb75)){int llllIl;
llIIIIIl=lIlIIllI=-(0x1ca8+1642-0x2311);for(llllIl=(0xc65+1754-0x133f);llllIl<
interface->cur_altsetting->desc.bNumEndpoints;llllIl++){struct usb_host_endpoint
*endpoint=&interface->cur_altsetting->endpoint[llllIl];if((endpoint->desc.
bmAttributes&USB_ENDPOINT_XFERTYPE_MASK)==USB_ENDPOINT_XFER_BULK){if(endpoint->
desc.bEndpointAddress&USB_ENDPOINT_DIR_MASK)llIIIIIl=endpoint->desc.
bEndpointAddress;else lIlIIllI=endpoint->desc.bEndpointAddress;}}if(llIIIIIl!=-
(0x213b+463-0x2309)&&lIlIIllI!=-(0x2152+801-0x2472)){unsigned long flags;IlllI(
"\x44\x65\x74\x65\x63\x74\x65\x64\x20\x65\x6e\x64\x70\x6f\x69\x6e\x74\x73\x20\x30\x78\x25\x30\x32\x78\x20\x61\x6e\x64\x20\x30\x78\x25\x30\x32\x78" "\n"
,llIIIIIl,lIlIIllI);

spin_lock_irqsave(&lIlII->IlIIIl,flags);if(!lIlII->lllIIlI){lIlII->IIlIIlll=
interface->cur_altsetting->desc.bInterfaceNumber;lIlII->llllIllI=llIIIIIl;lIlII
->lIlllIlI=lIlIIllI;lIlII->lllIIlI=(0x1264+4296-0x232b);}else{
}spin_unlock_irqrestore(&lIlII->IlIIIl,flags);break;
}}}
return(0x15c5+2037-0x1dba);}void IllIlIll(struct IllIl*lIlII){unsigned long 
flags;spin_lock_irqsave(&lIlII->IlIIIl,flags);
if(lIlII->llIIIII){lllIllI(lIlII->llIIIII);lIlII->llIIIII=NULL;}
spin_unlock_irqrestore(&lIlII->IlIIIl,flags);}void lIIlIlII(struct IllIl*lIlII){
unsigned long flags;spin_lock_irqsave(&lIlII->IlIIIl,flags);
if(lIlII->llIIIII){lllIllI(lIlII->llIIIII);lIlII->llIIIII=NULL;}lIlII->lllIIlI=
(0xa+6877-0x1ae7);lIlII->llllIllI=-(0x580+7635-0x2352);lIlII->lIlllIlI=-
(0xcec+2733-0x1798);lIlII->IIlIIlll=-(0x1404+4316-0x24df);spin_unlock_irqrestore
(&lIlII->IlIIIl,flags);}int IIIlIllll(struct IlIII*IIIll,gfp_t llllI){lIIll 
IIlIl=(lIIll)(IIIll+(0x1666+822-0x199b));struct IllIl*lIlII=IIIll->lIlII;
unsigned long flags;int endpoint;



if(IIIll->lIlIll.IIIIIIIl)return-(0x3a5+8533-0x24f9);
if(!lIlII->lllIIlI)return-(0x104a+5520-0x25d9);endpoint=IIlIl->lIllIl.Endpoint;
endpoint|=(IIlIl->lIllIl.Flags&IIIIIl)?(0x6f7+6356-0x1f4b):(0x7d+5699-0x16c0);
if(endpoint!=lIlII->llllIllI&&endpoint!=lIlII->lIlllIlI)return-
(0x9a0+2677-0x1414);
spin_lock_irqsave(&lIlII->IlIIIl,flags);if(!lIlII->llIIIII){struct lllllllIl*
IlIlllII;


if(IIIll->lIllll!=llIIlIl){
spin_unlock_irqrestore(&lIlII->IlIIIl,flags);return-(0xb68+3472-0x18f7);}
IlIlllII=IIIll->IlIlII.IIIIl;if(IlIlllII&&endpoint==lIlII->lIlllIlI&&IIlIl->
lIllIl.IlIll==sizeof(struct lllllllIl)&&le32_to_cpu(IlIlllII->IIlIlIllI)==
1128420181&&IlIlllII->IIIIlllIl){
lIlII->llIIIII=lIIIIIIII(IIIll,llllI);if(lIlII->llIIIII){spin_unlock_irqrestore(
&lIlII->IlIIIl,flags);IIlIl->lIllIl.IllIll.IIIlII=sizeof(IIlIl->lIllIl);IIlIl->
lIllIl.IllIll.Status=(0x591+3406-0x12df);llIlII(IIIll,(0xcd6+5128-0x20de));
return(0xa6c+5040-0x1e1b);
}else{
}}}else{


struct IlIII*IlIllII;IlIllII=lIlII->llIIIII;lIlII->llIIIII=NULL;IlIllII->lIIIl=
IIIll->lIIIl;IlIllII->lIlIll.IIIIIIIl=(0x855+6516-0x21c8);IlIllII->lIlIll.
IlIIIllll=(0x15a0+1523-0x1b92);IlIllII->lIlIll.IIllIlIIl=IIIIlllI;IlIllII->
lIlIll.lIIlIllI=IIIIlllI;IlIllII->lIlIll.lIlllIlII=IIIIlllI;IlIllII->lIlIll.
llIIIlll=IIIIlllI;IlIllII->lIlIll.lIlIIlIIl=IlIIlllI;IlIllII->lIlIll.IlIllllI=
IIIlIIIl;IlIllII->lIlIll.IlIlllIlI=IIIlIIIl;IlIllII->lIlIll.IlIIIllI=IIIlIIIl;
IlIllII->lIlIll.lllllllI=IIIlIIIl;IIIll->lIlIll.IIIIIIIl=(0x192d+3464-0x26b4);
IIIll->lIlIll.IlIIIllll=(0xef3+5346-0x23d5);IIIll->lIlIll.IIllIlIIl=IIlIIIlI;
IIIll->lIlIll.lIIlIllI=IIlIIIlI;IIIll->lIlIll.lIlllIlII=IIlIIIlI;IIIll->lIlIll.
llIIIlll=IIlIIIlI;IIIll->lIlIll.lIlIIlIIl=IllIlIII;IIIll->lIlIll.IlIllllI=
IllIlIII;IIIll->lIlIll.IlIlllIlI=IllIlIII;IIIll->lIlIll.IlIIIllI=IllIlIII;IIIll
->lIlIll.lllllllI=IllIlIII;atomic_cmpxchg(&IIIll->state,llllIll,lIlIIIIl);
list_add_tail(&IlIllII->IlIlIl,&IIIll->IlIlIl);spin_unlock_irqrestore(&lIlII->
IlIIIl,flags);

IIIlIIlI(IlIllII,llllI);return(0xcbf+4292-0x1d83);
}spin_unlock_irqrestore(&lIlII->IlIIIl,flags);return-(0xdb4+755-0x10a6);
}
#endif 

