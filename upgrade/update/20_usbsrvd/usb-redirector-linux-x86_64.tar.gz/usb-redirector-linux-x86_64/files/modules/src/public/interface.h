/*
 *
 *  Copyright (C) 2007-2016 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IllIlIlll
#define IllIlIlll
#define lIIllIIl 			(1024L*1024L+4096L) 
struct IlIlIll{lllIl lIIIIII;};


#define llIlIIIlI			(0x1e7+7723-0x2012)
#define IIIIlllII			(0x18fc+2128-0x214b)
#define IlllIIlII			(0x83c+4082-0x182c)
#define IIlIlIIlI	(0x11d7+3150-0x1e22)
#define lIIllllll		(0x195a+1556-0x1f6a)
#define IIIlIlIlI			(0x88d+3818-0x1772)
#define IIIllIIll				(0x67c+1152-0xaf6)
#define lIIlllIIl	(0xe2+5324-0x15a7)
struct lllIllIll{struct IlIlIll IIIlIl;lllIl busnum;lllIl devnum;};struct 
lIlIlIIII{struct IlIlIll IIIlIl;lllIl lIllllI;};struct llIIlIIll{struct IlIlIll 
IIIlIl;lllIl lIIIllII;};struct IIIIIllII{struct IlIlIll IIIlIl;};struct 
lIlIlIIll{struct IlIlIll IIIlIl;lllIl IIllIIll;};


#define IIlllIIlI	(0x9b5+7509-0x270a)
#define IIlIllIll		(0x13e3+1121-0x1843)
#define IlIIIIIIl		(0x1a16+2891-0x255f)
#define lllIIIlll		(0x15ed+1471-0x1ba9)
#define llIlllIll		(0x3d6+5462-0x1929)



#define llIlIllIl				(0xfa2+3067-0x1b9c)	
#define IlIIlllll	(0x88c+7224-0x24c2)	
#define IlllIlIIl		(0x4c7+2653-0xf20)	






#define lIlIIlIII						((IIIII)(0x2a4+414-0x442))
#define llIIllIIl					((IIIII)(0xb42+1446-0x10e7))
#define lIlIlIllI					((IIIII)(0x6f1+6174-0x1f0d))
#define lIIIIIlIl					((IIIII)(0x158a+273-0x1698))
#define lIlIllIIl			(0x1032+1486-0x1600)
#define IIIllIIIl			(0x6fb+4811-0x19c5)
#define llllllIlI			(0x1c8+699-0x481)
struct llIlIlIlI{struct IlIlIll IIIlIl;lllIl llIIlIIlI;llIIIl lIIIIlIl;llIIIl 
IlllIlII;llIIIl llIllIll;llIIIl IIIlIlIII;IIIII lIIllIlII;
};struct IIllllIII{struct IlIlIll IIIlIl;lllIl llIIlIIlI;};struct llIIIIIll{
struct IlIlIll IIIlIl;};


#define IIIIIIllI			(0x15a1+2132-0x1df5)
#define lIlIIIlIl			(0x132f+2267-0x1c09)
#define lIIIIlIIl			(0x13cb+1214-0x1887)
#define IIIIlIlll			(0x116b+4272-0x2218)
#define IlIIIIIll			(0x3cb+2293-0xcbc)
struct lIlllIlIl{struct IlIlIll IIIlIl;lllIl IllIIIlI;
};struct IIIIIIlIl{struct IlIlIll IIIlIl;};struct llIIIIlII{struct IlIlIll 
IIIlIl;IIIII lIIIllIIl;char llIIll[(0x1c36+1925-0x239a)];
};struct IIlIIllIl{struct IlIlIll IIIlIl;IIIII IlllIIll;char llIIll[
(0x225a+123-0x22b4)];
};struct IllIlllll{struct IlIlIll IIIlIl;char llIIll[(0x176+8098-0x20f7)];
};


#define lIlIIlllI			(0x1ee3+1807-0x25f1)
#define IllIIIIll			(0x104a+505-0x1241)
#define lIIIllIlI			(0x11b3+1550-0x17bd)
#define IIllIIIIl		(0x790+2335-0x10a7)
#define lIIlllIlI	(0x12d+7944-0x2025)
#define lllllllII	(0xd08+2777-0x17c1)
#define llIllllII		(0xd5f+3436-0x1a8b)
#define IIlIllIl		(0x90+3620-0xe34)
#define IlIllIIII		(0x1ee5+1707-0x2390)
#define lllIlIllI		(0x86c+1228-0x938)
typedef struct llIlIlII{lllIl IlIIIlI;lllIl IlIIIlIl;lllIl llIlllIl;
llIIIl lIIIIlIl;llIIIl IlllIlII;llIIIl llIllIll;IIIII llllIIIll;IIIII lIIllIIll;
IIIII IIIllIlIl;

}IlIlIIIll,*llllIIllI;
#endif 

