/*
 *
 *  Copyright (C) 2007-2016 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IllIlIIlI
#define IllIlIIlI
#ifdef _USBD_ENABLE_STUB_
struct lIIllIl{struct list_head entry;struct llIlIlII lllII;};int llllllll(
struct usb_device*IlIIl);void llllIIIII(struct list_head*llIIIlII);void IlIlIIIl
(void);int IIIlllIll(struct usb_interface*IIllI);int IIIlIllI(struct usb_device*
IlIIl);void llllIIlI(struct usb_device*IlIIl,int IlllIIll);struct usb_device*
IIlIIIII(const char*llIIll);
#endif 
#endif 

