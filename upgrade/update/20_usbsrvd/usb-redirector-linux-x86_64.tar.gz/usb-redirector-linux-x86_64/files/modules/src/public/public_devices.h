/*
 *
 *  Copyright (C) 2007-2016 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IIllIll
#define IIllIll
#define IlIIIIlI "\x2f\x64\x65\x76"
#define llIIlII "\x74\x75\x73\x62\x64\x5f\x63\x64\x65\x76" 
#define llIlIIII \
"\x74\x75\x73\x62\x2d\x73\x74\x75\x62\x2d\x64\x72\x69\x76\x65\x72" 
#define llIIIll \
"\x74\x75\x73\x62\x2d\x76\x68\x63\x69\x2d\x64\x72\x69\x76\x65\x72" 
#endif 

